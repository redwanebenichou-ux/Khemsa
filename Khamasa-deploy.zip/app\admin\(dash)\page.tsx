"use client";
import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { dashboardStats, listProducts, syncAllShipments } from "@/lib/actions";
import type { DashboardStats } from "@/lib/services-misc";
import type { Product } from "@/lib/types";
import { Card, Badge, Empty, Button } from "@/components/ui";
import { money, statusLabel, statusColor, timeAgo, cn } from "@/lib/utils";
import {
  ShoppingCart, Eye, TrendingUp, Wallet, Package, Truck, Users, BarChart3,
  RefreshCcw, ArrowUpRight, ArrowDownRight, AlertTriangle, Receipt,
} from "lucide-react";

const KPI = ({ label, value, sub, tone, icon: Icon, trend }: {
  label: string; value: string; sub?: string; tone?: string;
  icon: React.ComponentType<{ className?: string }>; trend?: number;
}) => (
  <div className="card p-4 md:p-5 hover:shadow-pop transition-shadow">
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <div className="text-xs font-bold text-ink/50 truncate">{label}</div>
        <div className={cn("text-2xl md:text-3xl font-black mt-1 tabular-nums", tone)}>{value}</div>
        {sub && <div className="text-[11px] text-ink/45 mt-1 truncate">{sub}</div>}
      </div>
      <div className="shrink-0 w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center">
        <Icon className="w-5 h-5 text-golddark" />
      </div>
    </div>
    {typeof trend === "number" && (
      <div className={cn("mt-2 flex items-center gap-1 text-[11px] font-bold", trend >= 0 ? "text-emerald-700" : "text-red-600")}>
        {trend >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
        {Math.abs(trend)}% مقارنة بالأسبوع الماضي
      </div>
    )}
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [lowStock, setLowStock] = useState<Product[]>([]);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [syncing, setSyncing] = useState(false);

  async function load() {
    const [s, prods] = await Promise.all([dashboardStats(from || undefined, to || undefined), listProducts()]);
    setStats(s);
    setLowStock(prods.filter((p) => p.published && (p.stock <= p.lowStockThreshold || p.variants.some((v) => v.stock <= p.lowStockThreshold))));
  }
  useEffect(() => { load(); }, [from, to]);

  const weekBars = useMemo(() => {
    if (!stats) return [];
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(); d.setDate(d.getDate() - (6 - i));
      return d.toISOString().slice(0, 10);
    });
    return days.map((d) => ({
      day: d.slice(5),
      count: stats.recentOrders.filter((o) => o.createdAt.slice(0, 10) === d).length,
    }));
  }, [stats]);

  const maxBar = Math.max(1, ...weekBars.map((b) => b.count));

  const statusEntries = useMemo(() => {
    if (!stats) return [];
    return Object.entries(stats.byStatus).sort((a, b) => b[1] - a[1]);
  }, [stats]);

  async function sync() {
    setSyncing(true);
    try { await syncAllShipments(); await load(); }
    finally { setSyncing(false); }
  }

  if (!stats) return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="card p-5 h-28 animate-pulse bg-ink/5" />
      ))}
    </div>
  );

  const confirmed = stats.byStatus.confirmed ?? 0;
  const waiting = stats.byStatus.waiting ?? 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="h1">لوحة القيادة</h1>
          <p className="muted mt-1">نظرة عامة على أداء دار الخماسة — بيانات حقيقية من قاعدة البيانات</p>
        </div>
        <div className="flex items-center gap-2">
          <input type="date" className="input !w-auto" value={from} onChange={(e) => setFrom(e.target.value)} />
          <span className="muted text-xs">إلى</span>
          <input type="date" className="input !w-auto" value={to} onChange={(e) => setTo(e.target.value)} />
          <Button className="!py-2" onClick={sync} loading={syncing}>
            <RefreshCcw className="w-4 h-4" /> مزامنة
          </Button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <KPI label="إجمالي الطلبات" value={String(stats.totalOrders)} sub={`اليوم: ${stats.ordersToday}`} icon={ShoppingCart} />
        <KPI label="بانتظار التأكيد" value={String(waiting)} tone="text-amber-600" icon={Users} />
        <KPI label="مؤكدة" value={String(confirmed)} tone="text-emerald-700" icon={TrendingUp} />
        <KPI label="تم التوصيل" value={String(stats.deliveredCount ?? 0)} sub={`مرتجع: ${stats.returnedCount ?? 0}`} tone="text-green-700" icon={Truck} />
        <KPI label="الإيرادات (تم التوصيل)" value={money(stats.revenueDelivered)} sub={`قيد التنفيذ: ${money(stats.revenueConfirmedPipeline)}`} icon={Wallet} />
        <KPI label="التكاليف (تم التوصيل)" value={money(stats.costsDelivered)} icon={Receipt} />
        <KPI label="المصاريف" value={money(stats.expensesTotal)} icon={Receipt} />
        <KPI label="صافي الربح" value={money(stats.netProfit)} tone={stats.netProfit >= 0 ? "text-green-700" : "text-red-600"} sub="الطلبات الموصّلة فقط" icon={TrendingUp} />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Orders last 7 days */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="h2 flex items-center gap-2"><BarChart3 className="w-5 h-5 text-golddark" /> الطلبات — آخر 7 أيام</h2>
            <Link href="/admin/orders" className="text-xs font-black text-golddark">عرض الكل →</Link>
          </div>
          <div className="flex items-end gap-2 h-40">
            {weekBars.map((b) => (
              <div key={b.day} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full bg-gold/15 rounded-t-lg relative" style={{ height: `${(b.count / maxBar) * 100}%`, minHeight: b.count ? 6 : 2 }}>
                  <div className="absolute inset-0 bg-gold rounded-t-lg opacity-80" />
                </div>
                <span className="text-[10px] text-ink/45 font-bold">{b.day}</span>
                <span className="text-[10px] font-black">{b.count}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Status distribution */}
        <Card>
          <h2 className="h2 flex items-center gap-2 mb-3"><Package className="w-5 h-5 text-golddark" /> توزيع الحالات</h2>
          <div className="space-y-2">
            {statusEntries.length === 0 && <p className="muted text-sm">—</p>}
            {statusEntries.map(([s, n]) => {
              const pct = stats.totalOrders ? Math.round((n / stats.totalOrders) * 100) : 0;
              return (
                <div key={s} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span>{statusLabel(s)}</span>
                    <span className="text-ink/50">{n} ({pct}%)</span>
                  </div>
                  <div className="h-2 rounded-full bg-ink/5 overflow-hidden">
                    <div className={cn("h-full rounded-full", statusColor(s).split(" ")[0])} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-ink/5 text-xs text-ink/45">
            الزيارات: <b className="text-ink">{stats.views.toLocaleString("ar-DZ")}</b>
          </div>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Recent orders */}
        <Card className="lg:col-span-2 !p-0">
          <div className="flex items-center justify-between p-5 pb-3">
            <h2 className="h2 flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-golddark" /> أحدث الطلبات</h2>
            <Link href="/admin/orders" className="text-xs font-black text-golddark">عرض الكل →</Link>
          </div>
          {stats.recentOrders.length === 0 ? <Empty text="لا توجد طلبات بعد" /> : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr><th className="th px-5">الطلب</th><th className="th">العميل</th><th className="th">الهاتف</th><th className="th">المبلغ</th><th className="th">الحالة</th><th className="th px-5">الوقت</th></tr></thead>
                <tbody>
                  {stats.recentOrders.map((o) => (
                    <tr key={o.id} className="hover:bg-beige/40">
                      <td className="td px-5"><Link href="/admin/orders" className="font-black text-golddark">{o.number}</Link></td>
                      <td className="td font-bold">{o.customer.firstName} {o.customer.lastName}</td>
                      <td className="td" dir="ltr">{o.customer.phone}</td>
                      <td className="td font-black">{money(o.total)}</td>
                      <td className="td"><Badge className={statusColor(o.status)}>{statusLabel(o.status)}</Badge></td>
                      <td className="td px-5 muted !text-xs">{timeAgo(o.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {/* Side panels */}
        <div className="space-y-4">
          {/* Top sellers */}
          <Card>
            <h2 className="h2 flex items-center gap-2 mb-3"><Package className="w-5 h-5 text-golddark" /> الأكثر مبيعاً</h2>
            {stats.bestSellers.length === 0 ? <p className="muted text-sm">—</p> : (
              <ul className="space-y-2">
                {stats.bestSellers.map((b) => {
                  const max = stats.bestSellers[0]?.qty || 1;
                  const pct = Math.round((b.qty / max) * 100);
                  return (
                    <li key={b.productId} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-bold truncate">{b.name}</span>
                        <span className="muted shrink-0">{b.qty}×</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-ink/5 overflow-hidden">
                        <div className="h-full bg-gold rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          {/* Low stock */}
          {lowStock.length > 0 && (
            <Card className="!border-red-200 !bg-red-50">
              <h2 className="h2 text-red-700 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" /> مخزون منخفض
              </h2>
              <ul className="space-y-1 text-sm font-bold">
                {lowStock.map((p) => (
                  <li key={p.id}>
                    <Link href="/admin/products" className="text-red-700 underline">{p.name}</Link>
                    <span className="text-red-600/70"> — المتبقي: {p.stock}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {/* Recent audit */}
          <Card>
            <h2 className="h2 flex items-center gap-2 mb-3"><TrendingUp className="w-5 h-5 text-golddark" /> النشاط الأخير</h2>
            <ul className="space-y-2 text-xs">
              {(stats.recentAudit as { at: string; action: string; entity: string; detail?: string }[]).map((a, i) => (
                <li key={i} className="flex justify-between gap-2 border-b border-ink/5 pb-1.5 last:border-0">
                  <span className="font-bold truncate">{a.action} — {a.entity}</span>
                  <span className="muted shrink-0">{timeAgo(a.at)}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}

