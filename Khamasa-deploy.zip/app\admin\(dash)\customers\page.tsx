"use client";
import { useEffect, useState } from "react";
import { listCustomers, updateCustomerNotes } from "@/lib/actions";
import { Card, Badge, Empty, Button, Modal, Textarea } from "@/components/ui";
import { money, statusLabel, statusColor, timeAgo } from "@/lib/utils";
import { Phone, StickyNote } from "lucide-react";
import type { Order } from "@/lib/types";

interface CView { id: string; firstName: string; lastName: string; phone: string; wilaya?: string; commune?: string; address?: string; notes?: string; ordersCount: number; totalSpent: number; createdAt: string; updatedAt: string; orders: Order[]; }

export default function CustomersPage() {
  const [items, setItems] = useState<CView[]>([]);
  const [sel, setSel] = useState<CView | null>(null);
  const [notes, setNotes] = useState("");
  const [q, setQ] = useState("");

  async function load() { setItems(await listCustomers()); }
  useEffect(() => { load(); }, []);

  const filtered = items.filter((c) => !q || c.phone.includes(q) || `${c.firstName} ${c.lastName}`.includes(q));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="h1">العملاء</h1><p className="muted mt-1">سجل كامل لكل عميل — بدون إنشاء حساب، مرتبط برقم الهاتف</p></div>
        <input className="input !w-64" placeholder="بحث بالهاتف أو الاسم..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {filtered.length === 0 ? <Empty text="لا يوجد عملاء بعد" /> : (
        <Card className="!p-0 overflow-x-auto">
          <table className="w-full min-w-[700px]">
            <thead><tr><th className="th px-4 pt-4">العميل</th><th className="th">الهاتف</th><th className="th">الولاية</th><th className="th">عدد الطلبات</th><th className="th">إجمالي المشتريات</th><th className="th">أول طلب</th><th className="th px-4 pt-4">—</th></tr></thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-beige/40">
                  <td className="td px-4 font-bold">{c.firstName} {c.lastName}</td>
                  <td className="td" dir="ltr"><a href={`tel:${c.phone}`} className="text-golddark font-bold flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {c.phone}</a></td>
                  <td className="td text-xs">{c.wilaya ?? "—"}</td>
                  <td className="td font-black">{c.ordersCount}</td>
                  <td className="td font-black">{money(c.totalSpent)}</td>
                  <td className="td muted !text-xs">{timeAgo(c.createdAt)}</td>
                  <td className="td px-4"><button className="btn-ghost !text-xs" onClick={() => { setSel(c); setNotes(c.notes ?? ""); }}><StickyNote className="w-3.5 h-3.5" /> سجل وملاحظات</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={!!sel} onClose={() => setSel(null)} title={`سجل: ${sel?.firstName} ${sel?.lastName}`} wide>
        {sel && (
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-black text-sm mb-2">طلبات العميل ({sel.orders.length})</h3>
                <ul className="space-y-1.5 max-h-64 overflow-auto">
                  {sel.orders.map((o) => (
                    <li key={o.id} className="flex items-center justify-between border border-ink/10 rounded-lg px-3 py-2 text-sm">
                      <span className="font-black text-golddark">{o.number}</span>
                      <Badge className={statusColor(o.status)}>{statusLabel(o.status)}</Badge>
                      <span className="font-bold">{money(o.total)}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-black text-sm mb-2">ملاحظات داخلية</h3>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="تفضيلات العميل، سلوك الشراء..." />
                <Button className="mt-2" onClick={async () => { await updateCustomerNotes(sel.id, notes); await load(); setSel(null); }}>حفظ الملاحظات</Button>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
