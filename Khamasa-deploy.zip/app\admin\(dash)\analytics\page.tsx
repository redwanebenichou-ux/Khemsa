"use client";
import { useEffect, useState } from "react";
import { dashboardStats, listShipments } from "@/lib/actions";
import type { DashboardStats } from "@/lib/services-misc";
import { Stat, Card, Badge, Empty } from "@/components/ui";
import { money, statusLabel, statusColor, timeAgo } from "@/lib/utils";

const FUNNEL: { key: string; label: string }[] = [
  { key: "waiting", label: "في انتظار التأكيد" }, { key: "attempt1", label: "فشل التأكيد الأول" },
  { key: "attempt2", label: "فشل التأكيد الثاني" }, { key: "attempt3", label: "فشل التأكيد الثالث" },
  { key: "confirmed", label: "مؤكد" },
];

export default function AnalyticsPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  useEffect(() => { dashboardStats(from || undefined, to || undefined).then(setStats); }, [from, to]);
  if (!stats) return <div className="p-10 muted font-bold">جارٍ التحميل...</div>;

  const visits = stats.views || 1;
  const submissions = stats.totalOrders || 0;
  const confirmed = stats.byStatus.confirmed ?? 0;
  const delivered = stats.deliveredCount ?? 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div><h1 className="h1">التحليلات</h1><p className="muted mt-1">أداء حقيقي — زيارات، طلبات، تأكيدات، توصيل (بدون Pixel — قياس داخلي)</p></div>
        <div className="flex gap-2">
          <input type="date" className="input !w-auto" value={from} onChange={(e) => setFrom(e.target.value)} />
          <input type="date" className="input !w-auto" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="زيارات الصفحات" value={stats.views.toLocaleString("ar-DZ")} />
        <Stat label="معدل تحويل → طلب" value={`${((submissions / visits) * 100).toFixed(1)}%`} sub={`${submissions} طلب / ${stats.views} زيارة`} />
        <Stat label="معدل التأكيد (بعد المكالمة)" value={`${submissions ? ((confirmed / submissions) * 100).toFixed(1) : 0}%`} sub={`${confirmed} من ${submissions}`} />
        <Stat label="معدل التوصيل" value={`${confirmed ? ((delivered / confirmed) * 100).toFixed(1) : 0}%`} sub={`${delivered} موصّل من ${confirmed} مؤكد`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <h2 className="h2 mb-4">قمع التحويل</h2>
          <div className="space-y-2.5">
            {FUNNEL.map((f) => {
              const v = stats.byStatus[f.key] ?? 0;
              const pct = submissions ? Math.round((v / submissions) * 100) : 0;
              return (
                <div key={f.key}>
                  <div className="flex justify-between text-xs font-bold mb-1"><span>{f.label}</span><span className="muted">{v} ({pct}%)</span></div>
                  <div className="h-2.5 bg-beige rounded-full overflow-hidden"><div className="h-full bg-gold rounded-full transition-all" style={{ width: `${pct}%` }} /></div>
                </div>
              );
            })}
          </div>
        </Card>
        <Card>
          <h2 className="h2 mb-4">توزيع الحالات</h2>
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.byStatus).map(([s, v]) => (
              <div key={s} className="border border-ink/10 rounded-lg px-3 py-2">
                <Badge className={statusColor(s)}>{statusLabel(s)}</Badge>
                <div className="text-xl font-black mt-1">{v}</div>
              </div>
            ))}
          </div>
          <h2 className="h2 mt-6 mb-3">الأكثر مبيعاً</h2>
          <ul className="space-y-2">
            {stats.bestSellers.map((b) => (
              <li key={b.productId} className="flex justify-between text-sm border-b border-ink/5 pb-1.5">
                <span className="font-bold">{b.name}</span><span className="muted">{b.qty} قطعة · {money(b.revenue)}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
