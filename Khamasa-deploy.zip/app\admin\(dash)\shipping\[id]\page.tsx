"use client";
import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { getShipment, syncShipment, getOrder } from "@/lib/actions";
import type { Shipment, Order } from "@/lib/types";
import { Card, Badge, Button } from "@/components/ui";
import { courierStatusLabel, courierStatusColor } from "@/lib/utils";

import { ArrowLeft, Truck, Package, MapPin, RefreshCcw, Loader2 } from "lucide-react";
import TrackingMap from "@/components/admin/tracking-map";

export default function ShipmentDetailPage() {
  const router = useRouter();
  const params = useParams();
  const shipmentId = params.id as string;

  const [shipment, setShipment] = useState<Shipment | null>(null);
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const sh = await getShipment(shipmentId);
        if (sh) {
          setShipment(sh);
          const o = await getOrder(sh.orderId);
          if (o) setOrder(o);
          else router.push("/admin/shipping");
        } else {
          // الشحنة غير موجودة
          router.push("/admin/shipping");
        }
      } catch (error) {
        console.error("Error loading shipment:", error);
        router.push("/admin/shipping");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [shipmentId, router]);

  const handleSync = async () => {
    if (!shipment) return;

    setSyncing(true);
    try {
      await syncShipment(shipment.id);
      // إعادة تحميل البيانات بعد التحديث
      const updatedShipment = await getShipment(shipment.id);
      if (updatedShipment) {
        setShipment(updatedShipment);
      }
    } catch (error) {
      console.error("Error syncing shipment:", error);
    } finally {
      setSyncing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!shipment || !order) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <p>الشحنة غير موجودة</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* رجوع للصفحة الرئيسية */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" onClick={() => router.push("/admin/shipping")}>
          <ArrowLeft className="w-4 h-4" /> الرجوع
        </Button>
        <h1 className="h1">تفاصيل الشحنة</h1>
      </div>

      {/* معلومات الشحنة */}
      <Card>
        <div className="p-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h2 className="h2 flex items-center gap-2 mb-3">
                <Truck className="w-5 h-5 text-golddark" />
                معلومات الشحنة
              </h2>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-brown/60">رقم التتبع:</span>
                  <span className="font-bold" dir="ltr">{shipment.trackingNumber}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">الحالة:</span>
                  <Badge className={courierStatusColor(shipment.status)}>{courierStatusLabel(shipment.status)}</Badge>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">نوع التوصيل:</span>
                  <span className="font-bold">{shipment.method === "home" ? "توصيل للمنزل" : "توصيل لمكتب التوقف"}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">التكلفة المطلوبة من العميل:</span>
                  <span className="font-bold">{shipment.feeCharged.toLocaleString("ar-DZ")} دج</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">التكلفة الفعلية:</span>
                  <span className="font-bold">{shipment.costActual ? shipment.costActual.toLocaleString("ar-DZ") + " دج" : "لم تُدخل بعد"}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">طريقة الإنشاء:</span>
                  <Badge className={shipment.apiMode === "live" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"}>
                    {shipment.apiMode === "live" ? "API حي" : "محلي"}
                  </Badge>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">تاريخ الإنشاء:</span>
                  <span className="font-bold">{new Date(shipment.createdAt).toLocaleString("ar-DZ")}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">آخر تحديث:</span>
                  <span className="font-bold">{new Date(shipment.updatedAt).toLocaleString("ar-DZ")}</span>
                </div>
              </div>
            </div>

            {/* معلومات الطلب */}
            <div>
              <h2 className="h2 flex items-center gap-2 mb-3">
                <Package className="w-5 h-5 text-golddark" />
                معلومات الطلب
              </h2>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-brown/60">رقم الطلب:</span>
                  <span className="font-bold" dir="ltr">{order.number}</span>
                </div>

                <div>
                  <span className="text-brown/60 block mb-1">العميل:</span>
                  <div className="font-bold">{order.customer.firstName} {order.customer.lastName}</div>
                  <div className="text-sm text-brown/60 mt-1">{order.customer.phone}</div>
                </div>

                <div>
                  <span className="text-brown/60 block mb-1">العنوان:</span>
                  <div className="font-bold">{order.customer.address}</div>
                  <div className="text-sm text-brown/60 mt-1">{order.customer.commune}، {order.customer.wilaya}</div>
                </div>

                <div>
                  <span className="text-brown/60 block mb-1">المنتجات:</span>
                  <div className="space-y-1">
                    {order.items.map((item, index) => (
                      <div key={index} className="text-sm">
                        <span className="font-bold">{item.productName}</span>
                        {item.variantName && ` (${item.variantName})`}
                        <span className="text-brown/600 ml-2">×{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between">
                  <span className="text-brown/60">إجمالي الطلب:</span>
                  <span className="font-bold">{order.total.toLocaleString("ar-DZ")} دج</span>
                </div>
              </div>
            </div>
          </div>

          {/* أزرار العمل */}
          <div className="flex gap-3 mt-6 flex-wrap">
            <Button 
              onClick={handleSync}
              disabled={syncing}
              className="flex items-center gap-2"
            >
              <RefreshCcw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
              {syncing ? "جاري التحديث..." : "تحديث بيانات التتبع"}
            </Button>
            {shipment.apiMode === "live" && (
              <a href={`/admin/shipments/${shipment.id}/label`} target="_blank" rel="noreferrer"
                className="btn-gold flex items-center gap-2">
                طباعة تيكت رسمي (DHD)
              </a>
            )}
          </div>
        </div>
      </Card>

      {/* خريطة التتبع */}
      {shipment.trackingNumber && (
        <TrackingMap shipment={shipment} order={order} />
      )}

      {/* سجل أحداث الشحنة */}
      <Card>
        <div className="p-4">
          <h2 className="h2 flex items-center gap-2 mb-3">
            <MapPin className="w-5 h-5 text-golddark" />
            سجل أحداث الشحنة
          </h2>

          <div className="space-y-4">
            {shipment.events.length > 0 ? (
              shipment.events.map((event, index) => (
                <div key={index} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-3 h-3 bg-gold rounded-full"></div>
                    {index < shipment.events.length - 1 && <div className="w-0.5 h-full bg-brown/10"></div>}
                  </div>
                  <div className="flex-1 pb-3">
                    <div className="text-sm font-bold text-brown">{courierStatusLabel(event.status)}</div>
                    <div className="text-xs text-brown/60">{event.detail}</div>
                    <div className="text-xs text-brown/40 mt-1">{new Date(event.at).toLocaleString("ar-DZ")}</div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-brown/60 py-4">لا توجد أحداث مسجلة لهذه الشحنة</p>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
