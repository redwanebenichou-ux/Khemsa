import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { getDB } from "@/lib/db/store";
import type { Product } from "@/lib/types";
import Header from "@/components/storefront/landing/header";
import TopSection from "@/components/storefront/landing/top-section";
import Reviews from "@/components/storefront/landing/reviews";
import OrderForm, { StickyOrderBar } from "@/components/storefront/landing/order-form";
import Footer from "@/components/storefront/landing/footer";

export const dynamic = "force-dynamic";

async function getPublishedProduct(slug: string): Promise<Product | null> {
  // Next.js قد يسلّم الرابط percent-encoded للروابط العربية — نجرب المفكوك أيضاً
  let s = slug;
  try { s = decodeURIComponent(slug); } catch { /* تبقى كما هي */ }
  const db = await getDB();
  return db.products.find((x) => (x.slug === s || x.slug === slug) && x.published) ?? null;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const p = await getPublishedProduct(params.slug);
  if (!p) return {};
  // بطاقة المشاركة (فيسبوك/إنستغرام/رسائل): صورة المنتج + الاسم + السعر
  const h = headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = process.env.NEXT_PUBLIC_SITE_URL || `${proto}://${host}`;
  const rawImg = p.images[0]?.url;
  const img = !rawImg ? `${origin}/logo.png` : rawImg.startsWith("http") ? rawImg : `${origin}${rawImg}`;
  // عنوان بطاقة المشاركة من اسم المنتج دائماً (لا يعتمد على إعدادات SEO القديمة)
  const ogTitle = `${p.name} — دار الخماسة`;
  const desc = `${p.shortDescription} — ${p.price.toLocaleString("ar-DZ")} دج · الدفع عند الاستلام · توصيل لجميع الولايات`;
  // عنوان التبويب: من إعدادات SEO إن كانت سليمة، وإلا من الاسم
  const seoTitle = p.landing.seoTitle || "";
  const metaTitle = seoTitle && !seoTitle.startsWith(" — ") ? seoTitle : ogTitle;
  const metaDesc = p.landing.seoDescription || desc;
  return {
    title: metaTitle,
    description: metaDesc,
    openGraph: {
      title: ogTitle, description: desc,
      images: [{ url: img, width: 1200, height: 630, alt: p.name }],
      type: "website", siteName: "دار الخماسة",
    },
    twitter: { card: "summary_large_image", title: ogTitle, description: desc, images: [img] },
  };
}

export default async function ProductLanding({ params }: { params: { slug: string } }) {
  const product = await getPublishedProduct(params.slug);
  if (!product) notFound();
  const db = await getDB();
  const settings = db.settings;
  const approved = db.reviews.filter((r) => r.productId === product.id && r.approved);
  const rating = approved.length ? approved.reduce((s, r) => s + r.rating, 0) / approved.length : 0;

  return (
    <main className="bg-cream min-h-screen">
      <Header settings={settings} promoText={product.landing.promoText} />

      {/* 1) الاسم والسعر أعلى الصفحة → 2) الصورة → 3) زر الطلب */}
      <TopSection product={product} rating={rating} reviewsCount={approved.length} />

      {/* 4) نموذج الطلب — مباشرة بعد الزر */}
      <section className="bg-warmbeige/70 py-6 md:py-8 border-t border-gold/10">
        <div className="max-w-2xl mx-auto px-4">
          <OrderForm
            product={product}
            rates={db.rates}
            defaultShipping={{ home: settings.defaultShippingHome, stopDesk: settings.defaultShippingStopDesk }}
             freeStopDesk={!!(product.freeStopDesk || settings.freeStopDeskShipping)}
             freeStopDeskAdvertising={settings.freeStopDeskAdvertising !== false}
             hideDeliveryMethodIcons={settings.hideDeliveryMethodIcons !== false}
          />
        </div>
      </section>

      {/* 5) بقية المعلومات */}
      
      <Reviews reviews={approved} />
      
      <Footer settings={settings} />
      <StickyOrderBar product={product} />
      {/* مساحة أسفل الشريط الثابت للموبايل */}
      <div className="h-16 md:hidden" />
    </main>
  );
}
