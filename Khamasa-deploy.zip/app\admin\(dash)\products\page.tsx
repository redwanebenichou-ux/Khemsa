"use client";
import { useEffect, useState } from "react";
import { listProducts, saveProduct, deleteProduct, duplicateProduct, addInventory, uploadFile, listReviews, saveReview, toggleReview, deleteReview } from "@/lib/actions";
import type { Product, Variant, Review, LandingConfig } from "@/lib/types";
import type { ProductInput } from "@/lib/services";
import { defaultLanding } from "@/lib/landing-defaults";
import { Card, Button, Input, Textarea, Field, Modal, Badge, Empty } from "@/components/ui";
import { money, cn, slugify } from "@/lib/utils";
import { Plus, Pencil, Copy, Trash2, Upload, PackagePlus, X, Star, ExternalLink, Check, Ban } from "lucide-react";

const emptyProduct = (): Partial<Product> => ({
  name: "", shortDescription: "", description: "",
  images: [], videos: [], sku: "", price: 0, costPrice: 0, compareAtPrice: undefined,
  stock: 0, lowStockThreshold: 5, variants: [], published: true,
  // landing تُهيأ على الخادم من اسم المنتج الفعلي عند الحفظ
  orderForm: { showQuantity: true, quantityDefault: 1, showNotes: true, requireVariant: false, ctaText: "تأكيد الطلب" },
});

type Tab = "product" | "landing" | "reviews";

export default function ProductsPage() {
  const [items, setItems] = useState<Product[]>([]);
  const [editing, setEditing] = useState<Partial<Product> | null>(null);
  const [tab, setTab] = useState<Tab>("product");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stockFor, setStockFor] = useState<string | null>(null);
  const [stockQty, setStockQty] = useState(10);
  const [stockReason, setStockReason] = useState("تزويد");
  const [msg, setMsg] = useState("");
  const [newReview, setNewReview] = useState({ author: "", rating: 5, text: "" });
  const [sizeType, setSizeType] = useState<"numbers" | "letters" | "custom">("letters");
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [customSizes, setCustomSizes] = useState("");

  async function load() { setItems(await listProducts()); }
  useEffect(() => { load(); }, []);

  function openEditor(p?: Product) {
    if (p) {
      setEditing(JSON.parse(JSON.stringify(p)));
      listReviews(p.id).then(setReviews);
      const sizes = Array.from(new Set((p.variants ?? []).map((v) => v.size).filter(Boolean))) as string[];
      const colors = Array.from(new Set((p.variants ?? []).map((v) => v.color).filter(Boolean))) as string[];
      setSelectedSizes(sizes);
      setSelectedColors(colors);
      const numberSet = ["36","37","38","39","40","41","42","43","44","45","46"];
      const letterSet = ["XS","S","M","L","XL","XXL"];
      if (sizes.length > 0 && sizes.every((s) => numberSet.includes(s))) setSizeType("numbers");
      else if (sizes.length > 0 && sizes.every((s) => letterSet.includes(s))) setSizeType("letters");
      else { setSizeType("custom"); setCustomSizes(sizes.join(",")); }
    } else {
      setEditing(emptyProduct());
      setReviews([]);
      setSelectedSizes([]);
      setSelectedColors([]);
    }
    setTab("product");
  }

  async function save() {
    if (!editing?.name?.trim()) { setMsg("أدخل اسم المنتج أولاً"); return; }
    try {
      const r = await saveProduct({ ...editing, name: editing.name!.trim() } as ProductInput);
      setEditing(null); setMsg(`تم حفظ "${r.name}" ✓ — صفحة الهبوط: /p/${r.slug}`); load();
    } catch (e) { setMsg(e instanceof Error ? e.message : "خطأ"); }
  }

  async function upload(f: React.ChangeEvent<HTMLInputElement>, kind: "image" | "video") {
    if (!f.target.files?.[0] || !editing) return;
    const fd = new FormData();
    fd.append("file", f.target.files[0]);
    const r = await uploadFile(fd);
    if (kind === "image") setEditing({ ...editing, images: [...(editing.images ?? []), { id: crypto.randomUUID(), url: r.url, alt: editing.name ?? "" }] });
    else setEditing({ ...editing, videos: [...(editing.videos ?? []), r.url] });
  }

  const setV = (k: string, v: unknown) => setEditing((e) => (e ? { ...e, [k]: v } : e));
  const setL = (k: keyof LandingConfig, v: unknown) =>
    setEditing((e) => (e ? { ...e, landing: { ...(e.landing ?? defaultLanding(e.name ?? "")), [k]: v } } : e));
  const setList = (k: "features" | "specs", i: number, v: string) => {
    if (!editing?.landing) return;
    const arr = [...(editing.landing[k] ?? [])];
    arr[i] = v;
    setL(k, arr);
  };
  const addList = (k: "features" | "specs") => setL(k, [...((editing?.landing?.[k] ?? []) as string[]), ""]);
  const delList = (k: "features" | "specs", i: number) => setL(k, ((editing?.landing?.[k] ?? []) as string[]).filter((_, x) => x !== i));
  const setFaq = (i: number, k: "q" | "a", v: string) => {
    if (!editing?.landing) return;
    const arr = [...(editing.landing.faq ?? [])];
    arr[i] = { ...arr[i], [k]: v };
    setL("faq", arr);
  };
  const setVariant = (i: number, k: string, v: unknown) => {
    if (!editing?.variants) return;
    const vs = [...editing.variants];
    vs[i] = { ...vs[i], [k]: v };
    setEditing({ ...editing, variants: vs });
  };

  const autoSlug = editing?.name ? slugify(editing.name) : "";

  // مزامنة المتغيرات مع الاختيارات (تفعيل/إلغاء)
  useEffect(() => {
    if (!editing) return;
    const sizes = sizeType === "custom" ? customSizes.split(",").map((s) => s.trim()).filter(Boolean) : selectedSizes;
    const colors = selectedColors.length ? selectedColors : [""];
    if (sizes.length === 0) return;
    const existing = editing.variants ?? [];
    const next: Variant[] = [];
    for (const sz of sizes) {
      for (const col of colors) {
        const found = existing.find((v) => v.size === sz && v.color === col);
        next.push(found ?? { id: crypto.randomUUID(), size: sz, color: col, sku: "", priceDelta: 0, stock: editing?.stock ?? 0 } as Variant);
      }
    }
    setEditing((e) => (e ? { ...e, variants: next } : e));
  }, [selectedSizes, selectedColors, sizeType, customSizes, editing?.id]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="h1">المنتجات وصفحاتها</h1>
          <p className="muted mt-1">كل منتج يحصل تلقائياً على صفحة هبوط موحدة على <span className="font-black" dir="ltr">/p/الرابط</span></p>
        </div>
        <Button onClick={() => openEditor()}><Plus className="w-4 h-4" /> منتج جديد</Button>
      </div>
      {msg && <div className="rounded-lg bg-gold/15 text-brown font-bold text-sm px-4 py-2.5">{msg}</div>}

      {items.length === 0 ? <Empty text="لا توجد منتجات — أنشئ أول منتج وستتولد صفحته تلقائياً" /> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((p) => (
            <Card key={p.id} className="overflow-hidden !p-0">
              <div className="aspect-[16/9] bg-warmbeige relative">
                {p.images[0] ? <img src={p.images[0].url} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-brown/30 text-xs font-bold">بدون صورة — ارفع صور المنتج</div>}
                <Badge className={cn("absolute top-2 right-2", p.published ? "bg-green-100 text-green-800" : "bg-gray-200 text-gray-600")}>{p.published ? "منشور" : "مسودة"}</Badge>
                {p.stock <= p.lowStockThreshold && <Badge className="absolute top-2 left-2 bg-red-100 text-red-700">مخزون منخفض: {p.stock}</Badge>}
              </div>
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-black">{p.name}</span>
                  <span className="font-black text-golddark whitespace-nowrap">{money(p.price)}</span>
                </div>
                <div className="text-xs muted" dir="ltr">/p/{p.slug}</div>
                <div className="text-xs muted">الرابط يُولّد تلقائياً من الاسم · المتغيرات: {p.variants.length} · التكلفة: {money(p.costPrice)}</div>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={() => openEditor(p)}><Pencil className="w-3.5 h-3.5" /> تعديل</button>
                  <a className="btn-ghost !px-2.5 !py-1.5 !text-xs !text-golddark" href={`/p/${p.slug}`} target="_blank"><ExternalLink className="w-3.5 h-3.5" /> فتح الصفحة</a>
                  <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={async () => { await duplicateProduct(p.id); load(); }}><Copy className="w-3.5 h-3.5" /> نسخ</button>
                  <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={() => setStockFor(p.id)}><PackagePlus className="w-3.5 h-3.5" /> مخزون</button>
                  <button className="btn-ghost !px-2.5 !py-1.5 !text-xs !text-red-600" onClick={async () => { if (confirm("حذف المنتج نهائياً؟")) { await deleteProduct(p.id); load(); } }}><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة التحرير */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.name ? `تعديل: ${editing.name}` : "منتج جديد"} wide>
        {editing && (
          <div className="space-y-4">
            <div className="flex gap-1 border-b border-brown/10">
              {([["product", "بيانات المنتج"], ["landing", "صفحة الهبوط"], ["reviews", "المراجعات"]] as [Tab, string][]).map(([t, label]) => (
                <button key={t} onClick={() => setTab(t)} className={cn("px-4 py-2 text-xs font-black rounded-t-lg transition", tab === t ? "bg-gold text-brown" : "text-brown/50 hover:text-brown")}>{label}</button>
              ))}
            </div>

            {tab === "product" && (
              <div className="space-y-4">
                <Field label="اسم المنتج (الرابط يُولّد تلقائياً منه)">
                  <Input value={editing.name} onChange={(e) => setV("name", e.target.value)} />
                  {autoSlug && <p className="text-[11px] text-brown/45 mt-1" dir="ltr">/p/{autoSlug}</p>}
                </Field>
                <div className="grid md:grid-cols-3 gap-3">
                  <Field label="سعر البيع"><Input type="number" value={editing.price} onChange={(e) => setV("price", +e.target.value)} /></Field>
                  <Field label="السعر قبل التخفيض"><Input type="number" value={editing.compareAtPrice ?? ""} onChange={(e) => setV("compareAtPrice", e.target.value ? +e.target.value : undefined)} /></Field>
                  <Field label="سعر الشراء (التكلفة)"><Input type="number" value={editing.costPrice} onChange={(e) => setV("costPrice", +e.target.value)} /></Field>
                  <Field label="المخزون"><Input type="number" value={editing.stock} onChange={(e) => setV("stock", +e.target.value)} /></Field>
                  <Field label="تنبيه نفاذ المخزون"><Input type="number" value={editing.lowStockThreshold} onChange={(e) => setV("lowStockThreshold", +e.target.value)} /></Field>
                  <Field label="SKU (تلقائي إن تُرك فارغاً)"><Input value={editing.sku} onChange={(e) => setV("sku", e.target.value)} /></Field>
                </div>
                <Field label="وصف مختصر (يظهر في الهيرو)"><Input value={editing.shortDescription} onChange={(e) => setV("shortDescription", e.target.value)} /></Field>
                <Field label="الوصف الكامل"><Textarea className="min-h-[110px]" value={editing.description} onChange={(e) => setV("description", e.target.value)} /></Field>

                <div>
                  <label className="label">صور المنتج</label>
                  <div className="flex flex-wrap gap-2">
                    {(editing.images ?? []).map((im, i) => (
                      <div key={im.id} className="relative w-20 h-20">
                        <img src={im.url} alt="" className="w-full h-full object-cover rounded-lg" />
                        <button className="absolute -top-1.5 -left-1.5 bg-red-600 text-white rounded-full w-5 h-5 text-xs font-black" onClick={() => setV("images", editing.images!.filter((_, x) => x !== i))}>×</button>
                      </div>
                    ))}
                    <label className="w-20 h-20 border-2 border-dashed border-brown/20 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-gold text-brown/40">
                      <Upload className="w-5 h-5" /><span className="text-[10px] font-bold">رفع صورة</span>
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => upload(e, "image")} />
                    </label>
                  </div>
                  <label className="label mt-3">فيديو المنتج (اختياري)</label>
                  <div className="flex gap-2">
                    <Input placeholder="رابط فيديو https://..." onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); const val = (e.target as HTMLInputElement).value.trim(); if (val) { setV("videos", [...(editing.videos ?? []), val]); (e.target as HTMLInputElement).value = ""; } } }} />
                    <label className="btn-ghost cursor-pointer"><Upload className="w-4 h-4" /> رفع فيديو<input type="file" accept="video/*" className="hidden" onChange={(e) => upload(e, "video")} /></label>
                  </div>
                  {(editing.videos ?? []).map((v, i) => (
                    <div key={i} className="flex items-center justify-between text-xs muted mt-1" dir="ltr">
                      <span className="truncate">{v}</span>
                      <button onClick={() => setV("videos", editing.videos!.filter((_, x) => x !== i))}><X className="w-3.5 h-3.5 text-red-500" /></button>
                    </div>
                  ))}
                </div>

                <div>
                  <label className="label">تفعيل المتغيرات (المقاس / اللون) — اضغط لتفعيل/إلغاء</label>
                  {/* نوع المقاس */}
                  <div className="flex gap-2 mb-2">
                    {(["numbers", "letters", "custom"] as const).map((t) => (
                      <button key={t} type="button" onClick={() => setSizeType(t)}
                        className={cn("btn-ghost !px-3 !py-1.5 !text-xs", sizeType === t && "!bg-gold !text-brown !font-black")}>
                        {t === "numbers" ? "أرقام" : t === "letters" ? "حروف" : "مخصص"}
                      </button>
                    ))}
                  </div>
                  {/* شرائح المقاسات */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {(sizeType === "numbers" ? ["36","37","38","39","40","41","42","43","44","45","46"] :
                      sizeType === "letters" ? ["XS","S","M","L","XL","XXL"] :
                      customSizes.split(",").map((s) => s.trim()).filter(Boolean)
                    ).map((sz) => (
                      <button key={sz} type="button"
                        onClick={() => setSelectedSizes((prev) => prev.includes(sz) ? prev.filter((x) => x !== sz) : [...prev, sz])}
                        className={cn("px-3 py-1.5 rounded-full text-xs font-bold border transition",
                          selectedSizes.includes(sz) ? "bg-gold text-brown border-gold" : "bg-white text-brown/60 border-brown/15 hover:border-gold")}>
                        {sz}
                      </button>
                    ))}
                    {sizeType === "custom" && (
                      <input className="input !w-48 !py-1.5 !text-xs" placeholder="مقاسات مفصولة بفاصلة" value={customSizes}
                        onChange={(e) => setCustomSizes(e.target.value)} />
                    )}
                  </div>
                  {/* شرائح الألوان */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {[
                      { name: "أسود", hex: "#000000" },
                      { name: "أبيض", hex: "#FFFFFF" },
                      { name: "بيج", hex: "#F5E7D7" },
                      { name: "بني", hex: "#21160F" },
                      { name: "ذهبي", hex: "#C99A45" },
                      { name: "وردي", hex: "#F4A6B8" },
                      { name: "أزرق", hex: "#3B82F6" },
                      { name: "أخضر", hex: "#22C55E" },
                    ].map((c) => (
                      <button key={c.name} type="button"
                        onClick={() => setSelectedColors((prev) => prev.includes(c.name) ? prev.filter((x) => x !== c.name) : [...prev, c.name])}
                        className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition",
                          selectedColors.includes(c.name) ? "bg-gold text-brown border-gold" : "bg-white text-brown/60 border-brown/15 hover:border-gold")}>
                        <span className="w-3 h-3 rounded-full border border-brown/20" style={{ backgroundColor: c.hex }} />
                        {c.name}
                      </button>
                    ))}
                  </div>
                  <div className="text-xs font-bold text-brown/60 mb-2">
                    المتغيرات المفعلة: {(editing.variants ?? []).length} — (المقاس × اللون)
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-3">
                  <Field label="نص زر الطلب في الصفحة"><Input value={editing.orderForm?.ctaText} onChange={(e) => setV("orderForm", { ...editing.orderForm!, ctaText: e.target.value })} /></Field>
                  <label className="flex items-center gap-2 text-sm font-bold self-end pb-2"><input type="checkbox" checked={editing.published} onChange={(e) => setV("published", e.target.checked)} /> منشور (الصفحة متاحة للزبائن)</label>
                  <label className="flex items-center gap-2 text-sm font-bold self-end pb-2"><input type="checkbox" checked={!!editing.freeStopDesk} onChange={(e) => setV("freeStopDesk", e.target.checked)} /> توصيل مجاني للمكتب (Stop Desk)</label>
                </div>
              </div>
            )}

            {tab === "landing" && (
              <div className="space-y-4">
                <Field label="نص العرض في الشريط العلوي (اتركه فارغاً للإخفاء)"><Input value={editing.landing?.promoText ?? ""} onChange={(e) => setL("promoText", e.target.value)} placeholder="مثال: عرض خاص لفترة محدودة — خصم 23%" /></Field>
                <div className="grid md:grid-cols-2 gap-3">
                  <Field label="شارة الصورة (الأكثر مبيعاً...)"><Input value={editing.landing?.badge ?? ""} onChange={(e) => setL("badge", e.target.value)} /></Field>
                  <Field label="العبارة التسويقية تحت العنوان"><Input value={editing.landing?.heroTagline ?? ""} onChange={(e) => setL("heroTagline", e.target.value)} /></Field>
                </div>
                <div>
                  <label className="label">مزايا "لماذا تختار منتجنا؟" (4 عناصر)</label>
                  <div className="space-y-2">
                    {([0, 1, 2, 3] as const).map((i) => (
                      <Input key={i} value={(editing.landing?.features ?? [])[i] ?? ""} onChange={(e) => setList("features", i, e.target.value)} placeholder={`الميزة ${i + 1}`} />
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="label !mb-0">المواصفات</label>
                    <button className="btn-ghost !px-2.5 !py-1 !text-[11px]" onClick={() => addList("specs")}><Plus className="w-3 h-3" /> سطر</button>
                  </div>
                  <div className="space-y-2">
                    {(editing.landing?.specs ?? []).map((s, i) => (
                      <div key={i} className="flex gap-2">
                        <Input value={s} onChange={(e) => setList("specs", i, e.target.value)} />
                        <button className="text-red-500" onClick={() => delList("specs", i)}><X className="w-4 h-4" /></button>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="label !mb-0">الأسئلة الشائعة</label>
                    <button className="btn-ghost !px-2.5 !py-1 !text-[11px]" onClick={() => setL("faq", [...(editing.landing?.faq ?? []), { q: "", a: "" }])}><Plus className="w-3 h-3" /> سؤال</button>
                  </div>
                  <div className="space-y-2">
                    {(editing.landing?.faq ?? []).map((f, i) => (
                      <div key={i} className="grid grid-cols-7 gap-2">
                        <Input className="col-span-3" placeholder="السؤال" value={f.q} onChange={(e) => setFaq(i, "q", e.target.value)} />
                        <Input className="col-span-3" placeholder="الجواب" value={f.a} onChange={(e) => setFaq(i, "a", e.target.value)} />
                        <button className="text-red-500 justify-self-center" onClick={() => setL("faq", editing.landing!.faq.filter((_, x) => x !== i))}><X className="w-4 h-4" /></button>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-3">
                  <Field label="عنوان SEO"><Input value={editing.landing?.seoTitle ?? ""} onChange={(e) => setL("seoTitle", e.target.value)} /></Field>
                  <Field label="وصف SEO"><Input value={editing.landing?.seoDescription ?? ""} onChange={(e) => setL("seoDescription", e.target.value)} /></Field>
                </div>
              </div>
            )}

            {tab === "reviews" && (
              <div className="space-y-4">
                <p className="muted text-xs bg-warmbeige rounded-lg p-3">أضف مراجعات حقيقية بعد أول مبيعات — تظهر في صفحة الهبوط بعد الموافقة فقط.</p>
                <div className="border border-brown/10 rounded-xl p-3 space-y-2">
                  <div className="grid md:grid-cols-4 gap-2">
                    <Input placeholder="اسم العميل" value={newReview.author} onChange={(e) => setNewReview({ ...newReview, author: e.target.value })} />
                    <select className="input" value={newReview.rating} onChange={(e) => setNewReview({ ...newReview, rating: +e.target.value })}>
                      {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} نجوم</option>)}
                    </select>
                    <Input className="md:col-span-2" placeholder="نص المراجعة" value={newReview.text} onChange={(e) => setNewReview({ ...newReview, text: e.target.value })} />
                  </div>
                  <Button className="!py-2 !text-xs" onClick={async () => {
                    if (!editing?.id || !newReview.text.trim()) return;
                    await saveReview({ productId: editing.id, ...newReview });
                    setNewReview({ author: "", rating: 5, text: "" });
                    setReviews(await listReviews(editing.id));
                  }}><Plus className="w-3.5 h-3.5" /> إضافة مراجعة</Button>
                </div>
                <div className="space-y-2">
                  {reviews.length === 0 && <p className="muted text-sm">لا مراجعات بعد.</p>}
                  {reviews.map((r) => (
                    <div key={r.id} className="flex items-center gap-2 border border-brown/10 rounded-lg p-2.5">
                      <span className="flex gap-0.5">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={cn("w-3.5 h-3.5", i < r.rating ? "fill-gold text-gold" : "text-brown/20")} />)}</span>
                      <span className="text-xs font-black">{r.author}</span>
                      <span className="text-xs muted truncate flex-1">{r.text}</span>
                      <button className={cn("btn-ghost !px-2 !py-1 !text-[10px]", r.approved && "!bg-green-100")} onClick={async () => { await toggleReview(r.id, !r.approved); setReviews(await listReviews(editing.id!)); }}>
                        {r.approved ? <><Check className="w-3 h-3" /> معروضة</> : <><Ban className="w-3 h-3" /> مخفية</>}
                      </button>
                      <button className="text-red-500" onClick={async () => { await deleteReview(r.id); setReviews(await listReviews(editing.id!)); }}><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-brown/10">
              <button className="btn-ghost" onClick={() => setEditing(null)}>إلغاء</button>
              <Button onClick={save}>حفظ المنتج</Button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة حركة مخزون */}
      <Modal open={!!stockFor} onClose={() => setStockFor(null)} title="حركة مخزون">
        <div className="space-y-3">
          <Field label="الكمية"><Input type="number" value={stockQty} onChange={(e) => setStockQty(+e.target.value)} /></Field>
          <Field label="السبب"><Input value={stockReason} onChange={(e) => setStockReason(e.target.value)} /></Field>
          <div className="flex justify-end gap-2">
            <button className="btn-ghost" onClick={() => setStockFor(null)}>إلغاء</button>
            <Button onClick={async () => { await addInventory(stockFor!, undefined, "in", stockQty, stockReason); setStockFor(null); load(); }}>إضافة (دخول)</Button>
            <button className="btn-danger" onClick={async () => { await addInventory(stockFor!, undefined, "out", stockQty, stockReason); setStockFor(null); load(); }}>خصم (خروج)</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
