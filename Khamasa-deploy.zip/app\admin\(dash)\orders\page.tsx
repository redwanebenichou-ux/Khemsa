"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { listOrders, listShipments, listProducts, setOrderStatus, sendOrdersToCourier, syncShipment, syncAllShipments } from "@/lib/actions";
import type { Order, OrderStatus, Shipment, Product } from "@/lib/types";
import { ORDER_STATUSES } from "@/lib/types";
import { Card, Badge, Empty, Modal, Button, Select, Field } from "@/components/ui";
import { money, statusLabel, statusLabelFr, statusColor, timeAgo, courierStatusLabel, courierStatusColor, cn } from "@/lib/utils";
import { Copy, Check, Send, RefreshCcw, Package, Filter, Phone, X, ChevronDown, ShoppingCart, Truck, MapPin } from "lucide-react";
import { WILAYAS } from "@/lib/wilayas";

const STATUS_BTNS: { s: OrderStatus; label: string; cls: string }[] = [
  { s: "waiting", label: "بانتظار التأكيد", cls: "bg-blue-600" },
  { s: "attempt1", label: "فشل 1", cls: "bg-orange-500" },
  { s: "attempt2", label: "فشل 2", cls: "bg-orange-700" },
  { s: "attempt3", label: "فشل 3", cls: "bg-red-600" },
  { s: "cancelled", label: "إلغاء", cls: "bg-gray-500" },
  { s: "confirmed", label: "مؤكد", cls: "bg-emerald-600" },
];

function courierStatus(sh?: Shipment | null): string | null {
  if (!sh) return null;
  return sh.events[sh.events.length - 1]?.status ?? sh.status;
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [tab, setTab] = useState<OrderStatus | "all" | "to_ship" | "delivered_c" | "returned_c">("all");
  const [q, setQ] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [fProduct, setFProduct] = useState("");
  const [fWilaya, setFWilaya] = useState("");
  const [fDate, setFDate] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [sendModal, setSendModal] = useState<{ open: boolean; running: boolean; done: boolean; results: { orderId: string; ok: boolean; tracking?: string; error?: string; existed?: boolean; number: string }[] }>({ open: false, running: false, done: false, results: [] });
  const [details, setDetails] = useState<Order | null>(null);
  const [copied, setCopied] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function load() {
    const [o, sh, p] = await Promise.all([listOrders("all"), listShipments(), listProducts()]);
    setOrders(o); setShipments(sh); setProducts(p);
  }
  useEffect(() => { load(); }, []);

  const shByOrder = useMemo(() => { const m = new Map<string, Shipment>(); for (const s of shipments) m.set(s.orderId, s); return m; }, [shipments]);

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      const sh = shByOrder.get(o.id);
      if (tab === "to_ship") { if (o.status !== "confirmed" || sh) return false; }
      else if (tab === "delivered_c") { if (!o.deliveredAt) return false; }
      else if (tab === "returned_c") { if (!sh || !["returned", "return_in_transit"].includes(sh.status)) return false; }
      else if (tab !== "all" && o.status !== tab) return false;
      if (q && !(o.number.includes(q) || o.customer.phone.includes(q) || `${o.customer.firstName} ${o.customer.lastName}`.includes(q))) return false;
      if (fProduct && !o.items.some((i) => i.productId === fProduct)) return false;
      if (fWilaya && String(o.customer.wilayaCode) !== fWilaya) return false;
      if (fDate && o.createdAt.slice(0, 10) !== fDate) return false;
      return true;
    });
  }, [orders, shByOrder, tab, q, fProduct, fWilaya, fDate]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: orders.length, to_ship: 0, delivered_c: 0, returned_c: 0 };
    for (const o of orders) { c[o.status] = (c[o.status] ?? 0) + 1; if (o.status === "confirmed" && !shByOrder.get(o.id)) c.to_ship++; if (o.deliveredAt) c.delivered_c++; const sh = shByOrder.get(o.id); if (sh && ["returned", "return_in_transit"].includes(sh.status)) c.returned_c++; }
    return c;
  }, [orders, shByOrder]);

  function missingFields(o: Order): string[] {
    const m: string[] = [];
    if (`${o.customer.firstName}${o.customer.lastName}`.trim().length < 3) m.push("الاسم");
    if (o.customer.phone.replace(/\D/g, "").length < 9) m.push("الهاتف");
    if (!o.customer.wilayaCode) m.push("الولاية");
    if (!o.customer.commune) m.push("البلدية");
    if (!o.items.length) m.push("المنتجات");
    return m;
  }
  const sendable = (o: Order) => o.status === "confirmed" && !shByOrder.get(o.id) && missingFields(o).length === 0;

  function copyPhone(p: string, key: string) {
    navigator.clipboard.writeText(p).then(() => { setCopied(key); setTimeout(() => setCopied(""), 1500); });
  }

  async function changeStatus(o: Order, s: OrderStatus) {
    if (s === o.status) return;
    setBusy(true);
    try { await setOrderStatus(o.id, s); await load(); setMsg(`تم تغيير حالة ${o.number} إلى: ${statusLabel(s)}`); }
    catch (e) { setMsg(e instanceof Error ? e.message : "خطأ"); }
    finally { setBusy(false); setTimeout(() => setMsg(""), 2500); }
  }

  function toggleSel(o: Order) {
    if (!sendable(o)) return;
    setSelected((s) => { const n = new Set(s); n.has(o.id) ? n.delete(o.id) : n.add(o.id); return n; });
  }
  const selectableInFilter = filtered.filter(sendable);
  const allSelected = selectableInFilter.length > 0 && selectableInFilter.every((o) => selected.has(o.id));

  function openSendModal(ids?: string[]) {
    const target = ids ?? Array.from(selected);
    const valid = target.filter((id) => { const o = orders.find((x) => x.id === id); return o && sendable(o); });
    setSendModal({ open: true, running: false, done: false, results: valid.map((id) => ({ orderId: id, ok: false, number: orders.find((x) => x.id === id)?.number ?? "" })) });
  }

  async function runSend() {
    setSendModal((m) => ({ ...m, running: true }));
    const ids = sendModal.results.map((r) => r.orderId);
    const res = await sendOrdersToCourier(ids);
    const numberById = new Map(orders.map((o) => [o.id, o.number]));
    setSendModal({ open: true, running: false, done: true, results: res.map((r) => ({ ...r, number: numberById.get(r.orderId) ?? "" })) });
    await load();
    setSelected(new Set());
  }

  async function syncAll() {
    setSyncing(true);
    try { await syncAllShipments(); await load(); setMsg("تمت مزامنة كل الشحنات النشطة مع DHD ✓"); }
    finally { setSyncing(false); setTimeout(() => setMsg(""), 3000); }
  }

  const selectedValid = Array.from(selected).filter((id) => { const o = orders.find((x) => x.id === id); return o && sendable(o); });

  function productImage(pid: string) {
    const p = products.find((x) => x.id === pid);
    return p?.images?.[0]?.url;
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="h1">الطلبات</h1>
          <p className="muted mt-1">كل الطلبات — الأحدث أولاً. غيّر الحالة بالأزرار الملونة، وحدّد المؤكد وأرسله إلى DHD</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-ghost" onClick={() => setShowFilters(!showFilters)}><Filter className="w-4 h-4" /> فلتر</button>
          <button className="btn-ghost flex items-center gap-2" onClick={syncAll} disabled={syncing}><RefreshCcw className="w-4 h-4" /> مزامنة الكل</button>
        </div>
      </div>
      {msg && <div className="rounded-lg bg-gold/15 text-brown font-bold text-sm px-4 py-2.5">{msg}</div>}

      {/* Filters */}
      {showFilters && (
        <Card className="grid md:grid-cols-4 gap-3">
          <Field label="المنتج">
            <Select value={fProduct} onChange={(e) => setFProduct(e.target.value)}>
              <option value="">كل المنتجات</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label="الولاية">
            <Select value={fWilaya} onChange={(e) => setFWilaya(e.target.value)}>
              <option value="">كل الولايات</option>
              {Array.from(new Set(orders.map((o) => o.customer.wilayaCode))).sort((a, b) => a - b).map((code) => {
                const w = WILAYAS.find((x) => x.code === code);
                return <option key={code} value={code}>{code} — {w?.ar}</option>;
              })}
            </Select>
          </Field>
          <Field label="التاريخ"><input type="date" className="input" value={fDate} onChange={(e) => setFDate(e.target.value)} /></Field>
          <div className="flex items-end"><button className="btn-ghost !text-xs" onClick={() => { setFProduct(""); setFWilaya(""); setFDate(""); }}>مسح الفلاتر</button></div>
        </Card>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {([
          ["all", "الكل"], ["waiting", "في انتظار التأكيد"], ["attempt1", "فشل 1"], ["attempt2", "فشل 2"], ["attempt3", "فشل 3"],
          ["confirmed", "مؤكد"], ["to_ship", "جاهز للإرسال"], ["cancelled", "ملغى"], ["delivered_c", "تم توصيله"], ["returned_c", "مرتجع"],
        ] as [typeof tab, string][]).map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-black transition", tab === t ? "bg-brown text-cream" : "bg-white text-brown/60 border border-brown/10 hover:border-gold")}>
            {label} {counts[t] ? `(${counts[t]})` : ""}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <input className="input !w-64" placeholder="بحث: رقم الطلب، الهاتف، الاسم..." value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn-ghost !text-xs" onClick={() => setSelected(new Set(orders.filter((o) => o.status === "confirmed" && sendable(o)).map((o) => o.id)))}>
          تحديد جميع المؤكدة
        </button>
        <button className="btn-ghost !text-xs !py-1" onClick={() => { setTab("confirmed"); }}>مؤكدة</button>
        <button className="btn-ghost !text-xs !py-1" onClick={() => { setTab("to_ship"); }}>جاهز للإرسال</button>
        <button className="btn-ghost !text-xs !py-1" onClick={() => { setTab("delivered_c"); }}>تم التوصيل اليوم</button>
        <button className="btn-ghost !text-xs !py-1" onClick={() => { setTab("all"); setFProduct(""); setFWilaya(""); setFDate(""); setQ(""); }}>مسح</button>
      </div>

      {/* Bulk bar */}
      {selected.size > 0 && (
        <div className="sticky top-16 z-30 rounded-xl bg-brown text-cream px-4 py-3 flex items-center gap-3 shadow-pop">
          <span className="font-black text-sm">{selected.size} محددة</span>
          <button className="btn-gold !py-2 !text-sm" onClick={() => openSendModal()}><Send className="w-4 h-4" /> إرسال إلى التوصيل</button>
          <button className="btn-ghost !py-2 !text-sm !text-cream" onClick={() => setSelected(new Set())}>إلغاء التحديد</button>
          {selectedValid.length < selected.size && <span className="text-xs text-red-300 font-bold">{selected.size - selectedValid.length} طلبات غير مؤهلة</span>}
        </div>
      )}

      {/* Orders list */}
      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-warmbeige flex items-center justify-center mb-4">
            <ShoppingCart className="w-8 h-8 text-brown/30" />
          </div>
          <p className="text-brown/50 font-bold">لا توجد طلبات في هذا التصنيف</p>
          <p className="text-xs text-brown/40 mt-1">جرّب تغيير الفلاتر أو انتظر طلبات جديدة</p>
        </div>
      ) : (
        <>
          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {filtered.map((o) => {
              const sh = shByOrder.get(o.id);
              const cStat = courierStatus(sh);
              const miss = missingFields(o);
              const img = productImage(o.items[0]?.productId);
              return (
                <Card key={o.id} className={cn("p-4 space-y-3", selected.has(o.id) && "ring-2 ring-gold")}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {img && <img src={img} alt="" className="w-10 h-10 rounded object-cover" />}
                      <div>
                        <div className="font-black text-golddark">{o.number}</div>
                        <div className="text-[10px] muted">{timeAgo(o.createdAt)}</div>
                      </div>
                    </div>
                    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold", statusColor(o.status))}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
                      {statusLabel(o.status)}
                    </span>
                  </div>
                  <div className="text-sm">
                    <div className="font-bold">{o.customer.firstName} {o.customer.lastName}</div>
                    <button onClick={() => copyPhone(o.customer.phone, o.id)} className={cn("text-xs flex items-center gap-1", copied === o.id ? "text-green-700 font-black" : "text-brown/60 hover:text-golddark")}>
                      <span dir="ltr">{o.customer.phone}</span> {copied === o.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    </button>
                    <div className="text-xs muted">{o.customer.wilaya} — {o.customer.commune}</div>
                  </div>
                  <div className="text-xs">
                    {o.items.map((i, ix) => <div key={ix}>{i.productName}{i.variantName ? ` (${i.variantName})` : ""} ×{i.quantity}</div>)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-black text-golddark">{money(o.total)}</span>
                    {sh && <span className={cn("text-[10px] font-bold", courierStatusColor(cStat ?? ""))}>{courierStatusLabel(cStat ?? "")}</span>}
                  </div>
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-brown/5">
                    <button className="btn-ghost !px-2 !py-1 !text-[10px]" onClick={() => setDetails(o)}>تفاصيل</button>
                    {sh ? (
                      <>
                        <button className="btn-ghost !px-2 !py-1 !text-[10px]" onClick={async () => { await syncShipment(sh.id); await load(); }}><RefreshCcw className="w-3 h-3" /> تحديث</button>
                        {sh.apiMode === "live" && <a href={`/admin/shipments/${sh.id}/label`} target="_blank" rel="noreferrer" className="btn-ghost !px-2 !py-1 !text-[10px]">طباعة</a>}
                      </>
                    ) : o.status === "confirmed" && (
                      sendable(o) ? <button className="btn-gold !px-2 !py-1 !text-[10px]" onClick={() => openSendModal([o.id])}><Send className="w-3 h-3" /> إرسال إلى التوصيل</button> :
                      <span className="text-[10px] text-red-600 font-bold">معلومات ناقصة: {missingFields(o).join("، ")}</span>
                    )}
                    <input type="checkbox" disabled={!sendable(o)} checked={selected.has(o.id)} onChange={() => toggleSel(o)} className="mr-auto" />
                  </div>
                </Card>
              );
            })}
          </div>
          {/* Desktop table */}
          <div className="hidden md:block">
            <Card className="!p-0 overflow-x-auto">
              <table className="w-full min-w-[1000px]">
                <thead><tr>
                  <th className="th px-3 pt-4 w-8"><input type="checkbox" checked={allSelected} onChange={() => {
                    setSelected(allSelected ? new Set() : new Set(selectableInFilter.map((o) => o.id)));
                  }} /></th>
                  <th className="th">الطلب</th><th className="th">العميل</th><th className="th">المنتج</th>
                  <th className="th">الولاية/البلدية</th><th className="th">المبلغ</th>
                  <th className="th">الحالة</th><th className="th">التوصيل (DHD)</th><th className="th">تفاصيل</th>
                </tr></thead>
                <tbody>
                  {filtered.map((o) => {
                    const sh = shByOrder.get(o.id);
                    const cStat = courierStatus(sh);
                    const miss = missingFields(o);
                    const img = productImage(o.items[0]?.productId);
                    return (
                      <tr key={o.id} className={cn("hover:bg-warmbeige/50 transition", selected.has(o.id) && "bg-gold/10")}>
                        <td className="td px-3">
                          <input type="checkbox" disabled={!sendable(o)} checked={selected.has(o.id)} onChange={() => toggleSel(o)}
                            title={sendable(o) ? "تحديد للإرسال" : "غير مؤهل للإرسال"} />
                        </td>
                        <td className="td">
                          <div className="font-black text-golddark">{o.number}</div>
                          <div className="text-[10px] muted">{timeAgo(o.createdAt)}</div>
                        </td>
                        <td className="td">
                          <div className="font-bold whitespace-nowrap">{o.customer.firstName} {o.customer.lastName}</div>
                          <button onClick={() => copyPhone(o.customer.phone, o.id)} className={cn("text-xs flex items-center gap-1 mt-0.5", copied === o.id ? "text-green-700 font-black" : "text-brown/60 hover:text-golddark")}>
                            <span dir="ltr">{o.customer.phone}</span> {copied === o.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </td>
                        <td className="td text-xs">
                          <div className="flex items-center gap-2">
                            {img && <img src={img} alt="" className="w-8 h-8 rounded object-cover shrink-0" />}
                            <div>
                              {o.items.map((i, ix) => <div key={ix}>{i.productName}{i.variantName ? ` (${i.variantName})` : ""} ×{i.quantity}</div>)}
                            </div>
                          </div>
                        </td>
                        <td className="td text-xs whitespace-nowrap">{o.customer.wilaya}<br /><span className="muted">{o.customer.commune}</span></td>
                        <td className="td font-black whitespace-nowrap">{money(o.total)}</td>
                        <td className="td relative">
                          <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold", statusColor(o.status))}>
                            <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
                            {statusLabel(o.status)}
                          </span>
                          <div className="relative mt-1">
                            <button className="btn-ghost !px-2 !py-1 !text-[10px] flex items-center gap-1" onClick={() => setOpenMenuId(openMenuId === o.id ? null : o.id)}>
                              تغيير <ChevronDown className="w-3 h-3" />
                            </button>
                            {openMenuId === o.id && (
                              <>
                                <div className="fixed inset-0 z-40" onClick={() => setOpenMenuId(null)} />
                                <div className="absolute top-full mt-1 right-0 z-50 bg-white rounded-xl shadow-pop border border-brown/10 py-1.5 w-44">
                                  {STATUS_BTNS.map((b) => (
                                    <button key={b.s} disabled={busy || b.s === o.status}
                                      onClick={async () => { setOpenMenuId(null); await changeStatus(o, b.s); }}
                                      className={cn("w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-brown hover:bg-warmbeige text-right", b.s === o.status && "bg-warmbeige/70 cursor-default")}>
                                      <span className={cn("w-2.5 h-2.5 rounded-full shrink-0", b.cls)} />
                                      {b.label}
                                      {b.s === o.status && <Check className="w-3.5 h-3.5 text-golddark mr-auto" />}
                                    </button>
                                  ))}
                                </div>
                              </>
                            )}
                          </div>
                        </td>
                        <td className="td">
                          {sh ? (
                            <div className="space-y-1">
                              <span className={cn("text-[10px] font-bold", courierStatusColor(cStat ?? ""))}>{courierStatusLabel(cStat ?? "")}</span>
                              <div className="text-[10px] font-bold text-brown/60" dir="ltr">{sh.trackingNumber}</div>
                              <button className="text-[10px] font-black text-golddark flex items-center gap-1" onClick={async () => { await syncShipment(sh.id); await load(); }}>
                                <RefreshCcw className="w-3 h-3" /> تحديث
                              </button>
                              {sh.apiMode === "live" && (
                                <a href={`/admin/shipments/${sh.id}/label`} target="_blank" rel="noreferrer" className="text-[10px] font-black text-golddark flex items-center gap-1">
                                  طباعة
                                </a>
                              )}
                            </div>
                          ) : o.status === "confirmed" ? (
                            sendable(o) ? (
                              <button className="btn-gold !px-2.5 !py-1.5 !text-[10px]" onClick={() => openSendModal([o.id])}><Send className="w-3 h-3" /> إرسال إلى التوصيل</button>
                            ) : (
                              <span className="text-[10px] text-red-600 font-bold">معلومات ناقصة: {missingFields(o).join("، ")}</span>
                            )
                          ) : (
                            <span className="muted text-xs">—</span>
                          )}
                        </td>
                        <td className="td">
                          <button className="btn-ghost !px-2.5 !py-1.5 !text-xs" onClick={() => setDetails(o)}>تفاصيل</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </Card>
          </div>
        </>
      )}

      {/* Send modal */}
      <Modal open={sendModal.open} onClose={() => setSendModal((m) => ({ ...m, open: false }))} title="إرسال الطلبيات إلى DHD" wide>
        <div className="space-y-2">
          {sendModal.results.map((r) => (
            <div key={r.orderId} className={cn("flex items-center justify-between gap-2 rounded-lg border p-2.5 text-sm", r.ok ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50")}>
              <span className="font-black text-brown">{r.number}</span>
              {sendModal.running ? <span className="muted text-xs">جارٍ الإرسال...</span>
                : r.ok ? <span className="font-bold text-green-700 flex items-center gap-1"><Check className="w-4 h-4" /> أُرسلت — تتبع: <span dir="ltr">{r.tracking}</span>{r.existed && " (مسبقاً)"}</span>
                : <span className="font-bold text-red-700">✗ {r.error}</span>}
            </div>
          ))}
          {sendModal.results.length === 0 && <p className="muted text-sm">لا توجد طلبات مؤهلة للإرسال.</p>}
          {!sendModal.done && sendModal.results.length > 0 && (
            <div className="pt-2 flex justify-end gap-2">
              <button className="btn-ghost" onClick={() => setSendModal((m) => ({ ...m, open: false }))}>إلغاء</button>
              <Button onClick={runSend} loading={sendModal.running}><Send className="w-4 h-4" /> إرسال {sendModal.results.length} طلبات إلى DHD الآن</Button>
            </div>
          )}
          {sendModal.done && (
            <div className="pt-2 flex justify-end"><Button onClick={() => { setSendModal((m) => ({ ...m, open: false })); load(); }}>تم — إغلاق</Button></div>
          )}
          <p className="text-[11px] muted pt-1">الإرسال ينشئ الشحنة على حسابك في DHD مباشرة عبر API — تحقق من العناوين قبل الإرسال.</p>
        </div>
      </Modal>

      {/* Details modal */}
      <Modal open={!!details} onClose={() => setDetails(null)} title={details ? `Commande ${details.number}` : ""} wide>
        {details && (() => {
          const w = WILAYAS.find((x) => x.code === details.customer.wilayaCode);
          const sh = shByOrder.get(details.id);
          return (
            <div className="space-y-4" dir="ltr">
              <div className="grid md:grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg border border-brown/15 p-3">
                  <div className="text-[10px] font-black text-brown/50 mb-1">CLIENT</div>
                  <div className="font-black text-brown">{details.customer.firstName} {details.customer.lastName}</div>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="font-bold" dir="ltr">{details.customer.phone}</span>
                    <button onClick={() => copyPhone(details.customer.phone, "d")} className={cn("btn-ghost !px-2 !py-0.5 !text-[10px]", copied === "d" && "!bg-green-100")}>{copied === "d" ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />} Copier</button>
                  </div>
                  <div className="mt-1 text-brown/60">Wilaya: <b>{w?.fr ?? details.customer.wilaya}</b> — Commune: <b>{w?.communes.find((c) => c.ar === details.customer.commune)?.fr ?? details.customer.commune}</b></div>
                  <div className="text-brown/60">Statut: <b>{statusLabelFr(details.status)}</b></div>
                </div>
                <div className="rounded-lg border border-brown/15 p-3">
                  <div className="text-[10px] font-black text-brown/50 mb-1">PRODUITS</div>
                  {details.items.map((i, ix) => (
                    <div key={ix} className="flex justify-between"><span>{i.productName}{i.variantName ? ` (${i.variantName})` : ""}</span><b>×{i.quantity}</b></div>
                  ))}
                  <div className="mt-2 border-t border-brown/10 pt-2 flex justify-between font-black text-golddark"><span>Total (COD)</span><span>{details.total.toLocaleString("fr-DZ")} DZD</span></div>
                  <div className="text-brown/60 mt-1">Livraison: <b>{details.method === "home" ? "À domicile" : "Stop Desk"}</b> — Frais: {details.shippingFee.toLocaleString("fr-DZ")} DZD</div>
                  <div className="text-brown/50 text-xs mt-1">{new Date(details.createdAt).toLocaleString("fr-FR")}</div>
                </div>
              </div>
              {sh && (
                <div className="rounded-lg bg-warmbeige p-3 text-sm" dir="ltr">
                  <div className="text-[10px] font-black text-brown/50 mb-1">LIVRAISON — DHD</div>
                  <div>Tracking: <b dir="ltr">{sh.trackingNumber}</b></div>
                  <div className="mt-1 flex items-center gap-2" dir="rtl"><Badge className={courierStatusColor(courierStatus(sh) ?? "")}>{courierStatusLabel(courierStatus(sh) ?? "")}</Badge>
                    <button className="text-[10px] font-black text-golddark flex items-center gap-1" onClick={async () => { await syncShipment(sh.id); await load(); setDetails(null); }} dir="rtl"><RefreshCcw className="w-3 h-3" /> تحديث التتبع</button></div>
                  {sh.events.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-brown/10" dir="rtl">
                      <div className="text-[10px] font-black text-brown/50 mb-2">سجل الأحداث</div>
                      <div className="space-y-2 max-h-40 overflow-auto">
                        {sh.events.map((ev, i) => (
                          <div key={i} className="flex gap-2 text-xs">
                            <div className="w-2 h-2 bg-gold rounded-full mt-1 shrink-0" />
                            <div>
                              <div className="font-bold text-brown">{courierStatusLabel(ev.status)}</div>
                              {ev.detail && <div className="text-brown/60">{ev.detail}</div>}
                              <div className="text-brown/40">{new Date(ev.at).toLocaleString("ar-DZ")}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
              <div className="flex justify-end"><Button onClick={() => setDetails(null)}>إغلاق</Button></div>
            </div>
          );
        })()}
      </Modal>
    </div>
  );
}