"use client";
import { useEffect, useState } from "react";
import { getSettings, saveSettings, getAudit } from "@/lib/actions";
import type { Settings, AuditLog } from "@/lib/types";
import { Card, Button, Input, Field, Textarea } from "@/components/ui";
import { timeAgo } from "@/lib/utils";
import { Save } from "lucide-react";

export default function SettingsPage() {
  const [s, setS] = useState<Settings | null>(null);
  const [audit, setAudit] = useState<AuditLog[]>([]);
  const [msg, setMsg] = useState("");

  useEffect(() => { getSettings().then(setS); getAudit().then(setAudit); }, []);
  if (!s) return <div className="p-10 muted font-bold">جارٍ التحميل...</div>;

  const set = (k: string, v: unknown) => setS({ ...s, [k]: v });

  return (
    <div className="space-y-5">
      <div><h1 className="h1">الإعدادات</h1><p className="muted mt-1">بيانات المتجر، التوصيل الافتراضي، والسجل التدقيقي</p></div>
      {msg && <div className="rounded-lg bg-gold/15 text-brown font-bold text-sm px-4 py-2.5">{msg}</div>}

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <h2 className="h2 mb-4">بيانات المتجر</h2>
          <div className="space-y-3">
            <Field label="اسم المتجر"><Input value={s.storeName} onChange={(e) => set("storeName", e.target.value)} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="الهاتف الرئيسي"><Input dir="ltr" value={s.storePhone} onChange={(e) => set("storePhone", e.target.value)} /></Field>
              <Field label="هاتف إضافي"><Input dir="ltr" value={s.storePhone2 ?? ""} onChange={(e) => set("storePhone2", e.target.value)} /></Field>
            </div>
            <Field label="العنوان"><Input value={s.address ?? ""} onChange={(e) => set("address", e.target.value)} /></Field>
            <Field label="بادئة رقم الطلب" hint="مثال DEK-1001"><Input dir="ltr" value={s.orderNumberPrefix} onChange={(e) => set("orderNumberPrefix", e.target.value)} /></Field>
          </div>
        </Card>

        <Card>
          <h2 className="h2 mb-4">فوتر صفحات الهبوط والتواصل</h2>
          <div className="space-y-3">
            <Field label="نبذة من نحن" hint="تظهر في فوتر صفحة الهبوط"><Textarea className="min-h-[70px]" value={s.aboutShort ?? ""} onChange={(e) => set("aboutShort", e.target.value)} /></Field>
            <Field label="العبارة التسويقية في الفوتر"><Input value={s.footerTagline ?? ""} onChange={(e) => set("footerTagline", e.target.value)} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="رابط فيسبوك"><Input dir="ltr" value={s.socials?.facebook ?? ""} onChange={(e) => set("socials", { ...(s.socials ?? {}), facebook: e.target.value })} /></Field>
              <Field label="رابط إنستغرام"><Input dir="ltr" value={s.socials?.instagram ?? ""} onChange={(e) => set("socials", { ...(s.socials ?? {}), instagram: e.target.value })} /></Field>
              <Field label="رابط تيك توك"><Input dir="ltr" value={s.socials?.tiktok ?? ""} onChange={(e) => set("socials", { ...(s.socials ?? {}), tiktok: e.target.value })} /></Field>
              <Field label="رابط يوتيوب"><Input dir="ltr" value={s.socials?.youtube ?? ""} onChange={(e) => set("socials", { ...(s.socials ?? {}), youtube: e.target.value })} /></Field>
            </div>
          </div>
        </Card>

        <Card>
          <h2 className="h2 mb-4">التوصيل والمالية الافتراضية</h2>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="توصيل منزل (افتراضي)" hint="تُستخدم إذا لم تُحدد ولاية في الجدول"><Input type="number" value={s.defaultShippingHome} onChange={(e) => set("defaultShippingHome", +e.target.value)} /></Field>
              <Field label="Stop Desk (افتراضي)"><Input type="number" value={s.defaultShippingStopDesk} onChange={(e) => set("defaultShippingStopDesk", +e.target.value)} /></Field>
              <Field label="تكلفة التغليف لكل طلب"><Input type="number" value={s.packagingCost} onChange={(e) => set("packagingCost", +e.target.value)} /></Field>
              <Field label="حد تنبيه المخزون الافتراضي"><Input type="number" value={s.lowStockDefault} onChange={(e) => set("lowStockDefault", +e.target.value)} /></Field>
            </div>
            <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={s.codEnabled} onChange={(e) => set("codEnabled", e.target.checked)} /> الدفع عند الاستلام (COD)</label>
          </div>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={async () => { await saveSettings(s); setMsg("تم حفظ الإعدادات ✓"); }}><Save className="w-4 h-4" /> حفظ الإعدادات</Button>
      </div>

      <Card>
        <h2 className="h2 mb-3">السجل التدقيقي (Audit Log)</h2>
        <div className="max-h-80 overflow-auto">
          <table className="w-full">
            <thead><tr><th className="th">الإجراء</th><th className="th">الكيان</th><th className="th">التفصيل</th><th className="th">بواسطة</th><th className="th">الوقت</th></tr></thead>
            <tbody>
              {audit.map((a) => (
                <tr key={a.id}>
                  <td className="td font-bold text-xs">{a.action}</td>
                  <td className="td text-xs">{a.entity}</td>
                  <td className="td text-xs muted">{a.detail ?? "—"}</td>
                  <td className="td text-xs muted">{a.actor ?? "—"}</td>
                  <td className="td text-xs muted whitespace-nowrap">{timeAgo(a.at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="!bg-beige/50">
        <h2 className="h2 mb-2">🔐 الأمان</h2>
        <ul className="text-sm space-y-1.5 list-disc pr-4">
          <li>بيانات الدخول من متغيرات البيئة — غيّر <code dir="ltr">ADMIN_EMAIL</code> و <code dir="ltr">ADMIN_PASSWORD</code> و <code dir="ltr">SESSION_SECRET</code> قبل النشر.</li>
          <li>توكن DHD يُخزن على الخادم فقط ولا يُرسل أبداً للمتصفح.</li>
          <li>عند ربط Supabase: تُفعّل RLS + Supabase Auth، وتنتقل الملفات إلى Storage.</li>
        </ul>
      </Card>
    </div>
  );
}
