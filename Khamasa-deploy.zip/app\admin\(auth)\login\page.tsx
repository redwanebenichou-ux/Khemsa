"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { login } from "@/lib/actions";
import { Loader2, Lock } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const [next, setNext] = useState("/admin");
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("next");
    if (p && p.startsWith("/admin")) setNext(p);
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setErr("");
    const r = await login(email, password);
    setLoading(false);
    if (r.ok) router.push(next);
    else setErr(r.error ?? "خطأ");
  }

  return (
    <main className="min-h-screen bg-ink flex items-center justify-center p-6" dir="rtl">
      <div className="w-full max-w-sm card !bg-brown !border-ivory/10 p-8 shadow-pop">
        <div className="text-center mb-6">
          <img src="/logo.png" alt="دار الخماسة" className="h-16 w-16 object-contain mx-auto" />
          <h1 className="text-2xl font-black text-ivory mt-3">دار الخماسة</h1>
          <p className="text-ivory/50 text-sm mt-1">تسجيل دخول الإدارة</p>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <input className="input !bg-ink/60 !text-ivory !border-ivory/15" placeholder="البريد الإلكتروني" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          <div className="relative">
            <Lock className="w-4 h-4 absolute top-3.5 right-3 text-ivory/40" />
            <input className="input !bg-ink/60 !text-ivory !border-ivory/15 !pr-9" placeholder="كلمة المرور" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {err && <div className="text-red-300 text-sm font-bold bg-red-500/10 rounded-lg p-2.5 text-center">{err}</div>}
          <button className="btn-gold w-full !py-3" disabled={loading}>{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "دخول"}</button>
        </form>
        <p className="text-center text-[11px] text-ivory/35 mt-4">محاولات الدخول محمية — عند نسيان البيانات غيّر ADMIN_EMAIL وADMIN_PASSWORD في ملف البيئة</p>
      </div>
    </main>
  );
}
