"use client";
import { useEffect, useState } from "react";
import { getInventory, listProducts, addInventory } from "@/lib/actions";
import type { InventoryMovement, Product } from "@/lib/types";
import { Card, Badge, Empty, Button, Input, Field, Select, Modal } from "@/components/ui";
import { timeAgo, cn } from "@/lib/utils";
import { PackagePlus } from "lucide-react";

export default function InventoryPage() {
  const [moves, setMoves] = useState<InventoryMovement[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [form, setForm] = useState({ productId: "", variantId: "", type: "in", quantity: 10, reason: "تزويد" });
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");

  async function load() {
    const [m, p] = await Promise.all([getInventory(), listProducts()]);
    setMoves(m); setProducts(p);
  }
  useEffect(() => { load(); }, []);

  const prod = (id: string) => products.find((p) => p.id === id);
  const lowStock = products.filter((p) => p.stock <= p.lowStockThreshold);

  async function submit() {
    try {
      await addInventory(form.productId, form.variantId || undefined, form.type as any, form.quantity, form.reason);
      setOpen(false); setMsg("تم تسجيل الحركة ✓"); load();
    } catch (e) { setMsg(e instanceof Error ? e.message : "خطأ"); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="h1">المخزون وحركاته</h1><p className="muted mt-1">سجل دقيق لكل دخول/خروج — منع البيع الزائد محسوب تلقائياً (المخزون − المحجوز في الطلبات)</p></div>
        <Button onClick={() => setOpen(true)} disabled={products.length === 0}><PackagePlus className="w-4 h-4" /> حركة جديدة</Button>
      </div>
      {msg && <div className="rounded-lg bg-gold/15 text-brown font-bold text-sm px-4 py-2.5">{msg}</div>}

      {lowStock.length > 0 && (
        <Card className="!border-red-200 !bg-red-50">
          <h2 className="h2 text-red-700 mb-2">⚠ تنبيهات مخزون منخفض</h2>
          <ul className="text-sm font-bold text-red-700 space-y-1">
            {lowStock.map((p) => <li key={p.id}>{p.name} — المتبقي {p.stock} (الحد {p.lowStockThreshold}){p.variants.length ? ` · متغيرات: ${p.variants.map((v) => `${v.size}/${v.color}: ${v.stock}`).join("، ")}` : ""}</li>)}
          </ul>
        </Card>
      )}

      <Card>
        <h2 className="h2 mb-3">المخزون الحالي</h2>
        <table className="w-full">
          <thead><tr><th className="th">المنتج</th><th className="th">SKU</th><th className="th">المخزون الفعلي</th><th className="th">الحد</th><th className="th">متغيرات</th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td className="td font-bold">{p.name}</td><td className="td text-xs" dir="ltr">{p.sku}</td>
                <td className="td font-black">{p.stock}</td><td className="td muted">{p.lowStockThreshold}</td>
                <td className="td text-xs">{p.variants.map((v) => `${v.size ?? ""}${v.color ? "/" + v.color : ""}: ${v.stock}`).join("، ") || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card>
        <h2 className="h2 mb-3">سجل الحركات ({moves.length})</h2>
        {moves.length === 0 ? <Empty text="لا توجد حركات بعد" /> : (
          <table className="w-full">
            <thead><tr><th className="th">النوع</th><th className="th">المنتج</th><th className="th">الكمية</th><th className="th">السبب</th><th className="th">الوقت</th></tr></thead>
            <tbody>
              {moves.slice(0, 100).map((m) => (
                <tr key={m.id}>
                  <td className="td"><Badge className={cn(m.type === "in" || m.type === "return" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700")}>{m.type === "in" ? "دخول" : m.type === "out" ? "خروج (بيع)" : m.type === "return" ? "إرجاع" : "تعديل"}</Badge></td>
                  <td className="td font-bold text-sm">{prod(m.productId)?.name ?? m.productId}</td>
                  <td className="td font-black">{m.quantity}</td>
                  <td className="td text-xs muted">{m.reason}</td>
                  <td className="td text-xs muted">{timeAgo(m.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="تسجيل حركة مخزون">
        <div className="space-y-3">
          <Field label="المنتج">
            <Select value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value, variantId: "" })}>
              <option value="">اختر...</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          {form.productId && prod(form.productId)?.variants.length ? (
            <Field label="المتغير (اختياري)">
              <Select value={form.variantId} onChange={(e) => setForm({ ...form, variantId: e.target.value })}>
                <option value="">المنتج كله</option>
                {prod(form.productId)!.variants.map((v) => <option key={v.id} value={v.id}>{[v.size, v.color].filter(Boolean).join(" / ")}</option>)}
              </Select>
            </Field>
          ) : null}
          <div className="grid grid-cols-2 gap-3">
            <Field label="النوع">
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="in">دخول (تزويد)</option><option value="out">خروج (هدر/تصحيح)</option><option value="adjustment">تعديل جرد</option>
              </Select>
            </Field>
            <Field label="الكمية"><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: +e.target.value })} /></Field>
          </div>
          <Field label="السبب"><Input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <div className="flex justify-end"><Button disabled={!form.productId} onClick={submit}>تسجيل</Button></div>
        </div>
      </Modal>
    </div>
  );
}
