"use client";
import { useEffect, useState } from "react";
import { listOffers, saveOffer, deleteOffer, listProducts } from "@/lib/actions";
import type { Offer, Product } from "@/lib/types";
import { Card, Badge, Empty, Button, Input, Field, Select, Modal } from "@/components/ui";
import { money, cn } from "@/lib/utils";
import { Plus, Pencil, Trash2 } from "lucide-react";

export default function OffersPage() {
  const [items, setItems] = useState<Offer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Partial<Offer> & { name: string }>({ name: "", type: "percent", value: 10, productIds: [], active: true });

  async function load() {
    const [of, pr] = await Promise.all([listOffers(), listProducts()]);
    setItems(of); setProducts(pr);
  }
  useEffect(() => { load(); }, []);

  const toggleProduct = (id: string) => setForm((f) => ({ ...f, productIds: (f.productIds ?? []).includes(id) ? f.productIds!.filter((x) => x !== id) : [...(f.productIds ?? []), id] }));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="h1">العروض والخصومات</h1><p className="muted mt-1">تُطبق تلقائياً في نموذج الطلب — بدون كود أو بكود محدد</p></div>
        <Button onClick={() => { setForm({ name: "", type: "percent", value: 10, productIds: [], active: true }); setOpen(true); }}><Plus className="w-4 h-4" /> عرض جديد</Button>
      </div>

      {items.length === 0 ? <Empty text="لا توجد عروض" /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {items.map((o) => (
            <Card key={o.id} className="flex items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 font-black">{o.name}
                  <Badge className={cn(o.active ? "bg-green-100 text-green-800" : "bg-gray-200 text-gray-600")}>{o.active ? "نشط" : "متوقف"}</Badge>
                </div>
                <div className="text-xs muted mt-1">
                  {o.type === "percent" ? `خصم ${o.value}%` : `خصم ${money(o.value)}`}
                  {o.code && ` · بكود: ${o.code}`} · {o.productIds.length === 0 ? "كل المنتجات" : `${o.productIds.length} منتج محدد`}
                  {o.end && ` · حتى ${new Date(o.end).toLocaleDateString("ar-DZ")}`}
                </div>
              </div>
              <div className="flex gap-1.5">
                <button className="btn-ghost !px-2.5 !py-1.5" onClick={() => { setForm(JSON.parse(JSON.stringify(o))); setOpen(true); }}><Pencil className="w-3.5 h-3.5" /></button>
                <button className="btn-ghost !px-2.5 !py-1.5 !text-red-600" onClick={async () => { await deleteOffer(o.id); load(); }}><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={form.id ? "تعديل العرض" : "عرض جديد"}>
        <div className="space-y-3">
          <Field label="اسم العرض"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="النوع">
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })}>
                <option value="percent">نسبة %</option><option value="fixed">مبلغ ثابت</option>
              </Select>
            </Field>
            <Field label="القيمة"><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: +e.target.value })} /></Field>
          </div>
          <Field label="كود الخصم (اختياري — فارغ = يطبق تلقائياً)"><Input value={form.code ?? ""} onChange={(e) => setForm({ ...form, code: e.target.value || undefined })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="بداية"><Input type="date" value={(form.start ?? "").slice(0, 10)} onChange={(e) => setForm({ ...form, start: e.target.value })} /></Field>
            <Field label="نهاية"><Input type="date" value={(form.end ?? "").slice(0, 10)} onChange={(e) => setForm({ ...form, end: e.target.value })} /></Field>
          </div>
          <div>
            <label className="label">المنتجات المستهدفة (فارغ = الكل)</label>
            <div className="flex flex-wrap gap-2">
              {products.map((p) => (
                <button key={p.id} onClick={() => toggleProduct(p.id)}
                  className={cn("px-3 py-1.5 rounded-lg text-xs font-bold border", (form.productIds ?? []).includes(p.id) ? "bg-ink text-ivory border-ink" : "border-ink/15")}>
                  {p.name}
                </button>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> نشط</label>
          <div className="flex justify-end"><Button disabled={!form.name} onClick={async () => { await saveOffer(form); setOpen(false); load(); }}>حفظ</Button></div>
        </div>
      </Modal>
    </div>
  );
}
