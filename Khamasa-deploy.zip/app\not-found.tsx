import Link from "next/link";

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-4 text-center px-6">
      <img src="/logo.png" alt="دار الخماسة" className="h-16 w-16 object-contain" />
      <h1 className="text-3xl font-black">الصفحة غير موجودة</h1>
      <p className="muted">ربما تم إلغاء نشر الصفحة أو الرابط غير صحيح.</p>
      <Link href="/" className="btn-gold mt-2">العودة للرئيسية</Link>
    </main>
  );
}
