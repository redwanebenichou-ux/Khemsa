import { notFound, redirect } from "next/navigation";
import { getOrder } from "@/lib/services-orders";
import { getShipment } from "@/lib/services-shipping";
import { getDB } from "@/lib/db/store";
import { money } from "@/lib/utils";
import PrintButton from "@/components/admin/print-button";

export const dynamic = "force-dynamic";

/** باركود بصري بسيط من رقم التتبع (زخرفي للمسح اليدوي والتحقق البصري) */
function Barcode({ value }: { value: string }) {
  const bars: number[] = [];
  for (const ch of value) {
    const c = ch.charCodeAt(0);
    bars.push((c % 4) + 1, ((c >> 2) % 3) + 1);
  }
  return (
    <svg viewBox={`0 0 ${bars.reduce((a, b) => a + b + 1, 0)} 40`} className="h-10 w-full" preserveAspectRatio="none">
      {(() => {
        let x = 0;
        return bars.map((w, i) => {
          const el = <rect key={i} x={x} y={0} width={w} height={40} fill="#21160F" />;
          x += w + 1;
          return el;
        });
      })()}
    </svg>
  );
}

export default async function ShipmentLabel({ params }: { params: { id: string } }) {
  const sh = await getShipment(params.id);
  if (!sh) notFound();
  // للشحنات الحية: تيكت رسمي من شركة التوصيل (labelUrl)
  if (sh.apiMode === "live" && sh.labelUrl) redirect(sh.labelUrl);
  const order = await getOrder(sh.orderId);
  if (!order) notFound();
  const db = await getDB();
  const s = db.settings;

  return (
    <div className="min-h-screen bg-warmbeige py-8 print:bg-white print:py-0">
      <div className="max-w-[420px] mx-auto print:max-w-none">
        <div className="flex justify-between items-center mb-3 print:hidden">
          <a href="/admin/shipping" className="btn-ghost !py-1.5 !text-xs">← الشحن</a>
          <PrintButton />
        </div>

        {/* التيكت */}
        <div className="bg-white rounded-xl border-2 border-brown shadow-card p-5 print:rounded-none print:border-2 print:shadow-none">
          <div className="flex items-center justify-between border-b-2 border-brown pb-3">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="" className="h-9 w-9 object-contain" />
              <div>
                <div className="font-black text-brown leading-none">{s.storeName}</div>
                <div className="text-[8px] text-golddark font-bold">DAR EL KHAMASA</div>
              </div>
            </div>
            <div className="text-left">
              <div className="text-[9px] text-brown/50 font-bold">شركة التوصيل</div>
              <div className="font-black text-brown text-sm">DHD Express</div>
            </div>
          </div>

          <div className="py-3 border-b border-dashed border-brown/30">
            <div className="flex justify-between text-[11px] font-bold text-brown/60 mb-1">
              <span>رقم الطلب: <span className="font-black text-brown">{order.number}</span></span>
              <span>التاريخ: {new Date(sh.createdAt).toLocaleDateString("ar-DZ")}</span>
            </div>
            <div className="text-[10px] text-brown/60 font-bold mb-2">رقم التتبع: <span className="font-black text-golddark" dir="ltr">{sh.trackingNumber}</span></div>
            <Barcode value={sh.trackingNumber ?? order.number} />
            <div className="mt-1 text-center text-[8px] text-brown/40 font-bold" dir="ltr">{sh.trackingNumber}</div>
          </div>

          <div className="py-3 border-b border-dashed border-brown/30 space-y-1 text-sm">
            <div className="text-[9px] font-black text-golddark mb-1">معلومات المستلم</div>
            <div className="font-black text-brown">{order.customer.firstName} {order.customer.lastName}</div>
            <div className="text-brown/75 font-bold" dir="ltr">{order.customer.phone}</div>
            <div className="text-brown/75">الولاية: {order.customer.wilaya} ({order.customer.wilayaCode}) — البلدية: {order.customer.commune}</div>
            <div className="text-brown/75">العنوان: {order.customer.address}</div>
            <div className="flex justify-between mt-1">
              <span className="text-xs font-bold text-brown/60">نوع التوصيل</span>
              <span className="text-xs font-black text-brown">{sh.method === "home" ? "توصيل إلى المنزل" : "مكتب Stop Desk"}</span>
            </div>
          </div>

          <div className="py-3 border-b border-dashed border-brown/30">
            <div className="text-[9px] font-black text-golddark mb-1">محتوى الطرد</div>
            {order.items.map((i, ix) => (
              <div key={ix} className="flex justify-between text-xs text-brown/80">
                <span>{i.productName} {i.variantName ? `(${i.variantName})` : ""}</span>
                <span className="font-bold">×{i.quantity}</span>
              </div>
            ))}
          </div>

          <div className="py-3 flex items-center justify-between">
            <span className="font-black text-brown text-sm">المبلغ المطلوب (COD)</span>
            <span className="font-black text-xl text-golddark">{money(order.total)}</span>
          </div>

          {sh.apiMode === "local" && (
            <div className="mt-1 rounded-lg bg-amber-50 border border-amber-300 text-amber-800 text-[10px] font-bold p-2 text-center print:hidden">
              تيكت محلي — أدخل توكن DHD لإنشاء شحنة حية برقم تتبع رسمي
            </div>
          )}
          <div className="mt-2 text-center text-[8px] text-brown/40 font-bold">تُطبع من نظام دار الخماسة · {new Date().toLocaleString("ar-DZ")}</div>
        </div>
      </div>
    </div>
  );
}
