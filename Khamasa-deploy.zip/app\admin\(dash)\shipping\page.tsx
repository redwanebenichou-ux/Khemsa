"use client";
import { useEffect, useState, useMemo } from "react";
import { listProviders, saveProvider, testProvider, getRates, saveRates, listFreeRules, saveFreeRules, listShipments, syncShipment, setShipmentCost, syncAllShipments, getSettings, saveSettings } from "@/lib/actions";
import type { ShippingProvider, ShippingRate, FreeShippingRule, Shipment } from "@/lib/types";
import { Card, Badge, Button, Input, Field, Select, Modal } from "@/components/ui";
import { WILAYAS } from "@/lib/wilayas";
import { money, cn, timeAgo, courierStatusLabel, courierStatusColor } from "@/lib/utils";
import { Plug, Rocket, Plus, Trash2, RefreshCcw, Eye, EyeOff, MapPin, Truck, Package, BarChart3, List, Settings2 } from "lucide-react";
import NotificationSystem, { useNotification } from "@/components/admin/notification-system";
import TrackingMap from "@/components/admin/tracking-map";

const TABS = [
  { id: "overview", label: "نظرة عامة", icon: BarChart3 },
  { id: "provider", label: "مزود DHD", icon: Plug },
  { id: "rates", label: "الأسعار والشحن المجاني", icon: Settings2 },
  { id: "shipments", label: "الشحنات", icon: List },
] as const;

type TabId = (typeof TABS)[number]["id"];

export default function ShippingPage() {
  const [tab, setTab] = useState<TabId>("overview");
  const [providers, setProviders] = useState<ShippingProvider[]>([]);
  const [rates, setRates] = useState<ShippingRate[]>([]);
  const [rules, setRules] = useState<FreeShippingRule[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [showToken, setShowToken] = useState(false);
  const [msg, setMsg] = useState("");
  const [rateQuery, setRateQuery] = useState("");
  const [ruleOpen, setRuleOpen] = useState(false);
  const [rule, setRule] = useState<Partial<FreeShippingRule>>({ label: "", type: "min_order", active: true });
  const [syncingAll, setSyncingAll] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [freeStopDesk, setFreeStopDesk] = useState(false);
  const [freeStopDeskWilayas, setFreeStopDeskWilayas] = useState<number[]>([]);
  const [freeStopDeskAdvertising, setFreeStopDeskAdvertising] = useState(true);
  const [hideDeliveryMethodIcons, setHideDeliveryMethodIcons] = useState(true);
  const [shipFilter, setShipFilter] = useState<"all" | "live" | "local">("all");
  const [shipStatus, setShipStatus] = useState("");

  const { success, error } = useNotification();

  async function load() {
    const [p, r, fr, sh, s] = await Promise.all([listProviders(), getRates(), listFreeRules(), listShipments(), getSettings()]);
    setProviders(p);
    setRates(r);
    setRules(fr);
    setShipments(sh);
    setFreeStopDesk(!!s.freeStopDeskShipping);
    setFreeStopDeskWilayas(s.freeStopDeskWilayas ?? []);
    setFreeStopDeskAdvertising(s.freeStopDeskAdvertising !== false);
    setHideDeliveryMethodIcons(s.hideDeliveryMethodIcons !== false);
  }

  useEffect(() => { load(); }, []);

  const dhd = providers.find((p) => p.code === "dhd");

  const kpis = useMemo(() => {
    const total = shipments.length;
    const live = shipments.filter((s) => s.apiMode === "live").length;
    const local = shipments.filter((s) => s.apiMode === "local").length;
    const delivered = shipments.filter((s) => s.status === "delivered").length;
    const returned = shipments.filter((s) => ["returned", "return_in_transit"].includes(s.status)).length;
    const inTransit = shipments.filter((s) => ["in_transit", "out_for_delivery", "picked_up"].includes(s.status)).length;
    const pendingSync = shipments.filter((s) => s.apiMode === "live" && !["delivered", "returned"].includes(s.status)).length;
    return { total, live, local, delivered, returned, inTransit, pendingSync };
  }, [shipments]);

  const filteredShipments = useMemo(() => {
    return shipments.filter((s) => {
      if (shipFilter === "live" && s.apiMode !== "live") return false;
      if (shipFilter === "local" && s.apiMode !== "local") return false;
      if (shipStatus && s.status !== shipStatus) return false;
      return true;
    });
  }, [shipments, shipFilter, shipStatus]);

  async function syncAll() {
    setSyncingAll(true);
    try { await syncAllShipments(); await load(); setMsg("تمت مزامنة كل الشحنات النشطة مع DHD ✓"); }
    finally { setSyncingAll(false); setTimeout(() => setMsg(""), 3000); }
  }

  return (
    <>
      <NotificationSystem />
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="h1">الشحن — DHD Express</h1>
            <p className="muted mt-1">إدارة شحنات DHD Express: إعداد، أسعار، قواعد، تتبع.</p>
          </div>
          {msg && <div className="rounded-lg bg-gold/15 text-brown font-bold text-sm px-4 py-2.5">{msg}</div>}
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-1.5 border-b border-brown/10 pb-2">
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={cn("flex items-center gap-2 px-4 py-2 rounded-t-lg text-sm font-bold transition",
                  tab === t.id ? "bg-gold text-ink shadow-sm" : "text-brown/60 hover:text-brown hover:bg-warmbeige")}>
                <Icon className="w-4 h-4" /> {t.label}
              </button>
            );
          })}
        </div>

        {/* Overview */}
        {tab === "overview" && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">إجمالي الشحنات</div><div className="text-2xl font-black mt-1">{kpis.total}</div></Card>
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">قيد النقل</div><div className="text-2xl font-black mt-1 text-blue-700">{kpis.inTransit}</div></Card>
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">تم التوصيل</div><div className="text-2xl font-black mt-1 text-green-700">{kpis.delivered}</div></Card>
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">مرتجع</div><div className="text-2xl font-black mt-1 text-red-600">{kpis.returned}</div></Card>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">شحنات حية (DHD)</div><div className="text-2xl font-black mt-1 text-emerald-700">{kpis.live}</div></Card>
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">شحنات محلية</div><div className="text-2xl font-black mt-1 text-amber-700">{kpis.local}</div></Card>
              <Card className="p-4"><div className="text-xs font-bold text-ink/50">بانتظار مزامنة</div><div className="text-2xl font-black mt-1 text-orange-600">{kpis.pendingSync}</div></Card>
            </div>
            <Card>
              <div className="flex items-center justify-between mb-3">
                <h2 className="h2 flex items-center gap-2"><Truck className="w-5 h-5 text-golddark" /> أحدث الشحنات</h2>
                <button className="btn-gold !py-2 !text-sm" onClick={syncAll} disabled={syncingAll}><RefreshCcw className="w-4 h-4" /> مزامنة الكل</button>
              </div>
              {shipments.length === 0 ? <p className="muted text-sm">لا توجد شحنات بعد.</p> : (
                <div className="space-y-2">
                  {shipments.slice(0, 5).map((s) => (
                    <div key={s.id} className="flex items-center justify-between gap-3 border border-brown/10 rounded-lg px-3 py-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge className={courierStatusColor(s.status)}>{courierStatusLabel(s.status)}</Badge>
                        <span className="font-bold text-brown/60" dir="ltr">{s.trackingNumber}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={cn(s.apiMode === "live" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")}>{s.apiMode === "live" ? "API" : "محلي"}</Badge>
                        <button className="text-[10px] font-black text-golddark" onClick={async () => { await syncShipment(s.id); await load(); }}>تحديث</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
            <Card>
              <h2 className="h2 flex items-center gap-2 mb-3"><Plug className="w-5 h-5 text-golddark" /> حالة DHD</h2>
              {dhd ? (
                <div className="flex items-center justify-between">
                  <span className="font-bold">{dhd.name}</span>
                  <Badge className={cn(dhd.token ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")}>{dhd.token ? "التوكن موجود — API جاهز" : "لا يوجد توكن — وضع محلي"}</Badge>
                </div>
              ) : <p className="muted text-sm">لا يوجد مزود.</p>}
            </Card>
          </div>
        )}

        {/* Provider */}
        {tab === "provider" && (
          <div className="space-y-5">
            {dhd && (
              <Card>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="h2 flex items-center gap-2"><Plug className="w-5 h-5 text-golddark" /> {dhd.name}</h2>
                  <Badge className={cn(dhd.token ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")}>{dhd.token ? "التوكن موجود — API جاهز" : "لا يوجد توكن — وضع محلي"}</Badge>
                </div>
                <div className="grid md:grid-cols-2 gap-3">
                  <Field label="عنوان API"><Input dir="ltr" value={dhd.apiBaseUrl} onChange={(e) => setProviders(providers.map((p) => p.id === dhd.id ? { ...p, apiBaseUrl: e.target.value } : p))} /></Field>
                  <Field label="التوكن" hint="يُحفظ على الخادم فقط ولا يظهر للعملاء">
                    <div className="relative">
                      <input className="input !pl-10" dir="ltr" type={showToken ? "text" : "password"} value={dhd.token ?? ""} placeholder="ألصق توكن DHD هنا" onChange={(e) => setProviders(providers.map((p) => p.id === dhd.id ? { ...p, token: e.target.value } : p))} />
                      <button type="button" className="absolute left-3 top-3 text-ink/40" onClick={() => setShowToken(!showToken)}>{showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                    </div>
                  </Field>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button onClick={async () => { await saveProvider({ id: dhd.id, apiBaseUrl: dhd.apiBaseUrl, token: dhd.token, sandbox: dhd.sandbox, active: dhd.active }); setMsg("تم حفظ بيانات DHD ✓"); load(); }}>حفظ</Button>
                  <button className="btn-ghost" onClick={async () => { await saveProvider({ id: dhd.id, apiBaseUrl: dhd.apiBaseUrl, token: dhd.token, sandbox: dhd.sandbox, active: dhd.active }); const t = await testProvider(dhd.id); setMsg(`${t.ok ? "✓" : "✗"} ${t.message}`); load(); }}><Rocket className="w-4 h-4" /> اختبار الاتصال</button>
                </div>
                <p className="text-[11px] text-ink/45 mt-3 leading-relaxed">ملاحظة: نقاط النهاية (endpoints) في المحوّل مبنية على النمط الشائع وستُطابق الوثائق الرسمية لـ DHD عند إدخال التوكن لأول مرة.</p>
              </Card>
            )}
          </div>
        )}

        {/* Rates & Free Shipping */}
        {tab === "rates" && (
          <div className="space-y-5">
            {/* Free stop-desk moved to per-product in /admin/products */}

            {/* Rates table */}
            <Card>
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <div>
                  <h2 className="h2">جدول أسعار التوصيل الثابت</h2>
                  <p className="muted text-xs mt-1">يُستخدم عندما لا تتوفر أسعار API حية — مميّز في نموذج الطلب بأنه "سعر ثابت"</p>
                </div>
                <div className="flex gap-2">
                  <Input className="!w-40" placeholder="بحث عن ولاية..." value={rateQuery} onChange={(e) => setRateQuery(e.target.value)} />
                  <Button onClick={async () => { await saveRates(rates); setMsg("تم حفظ الجدول ✓"); }}>حفظ الجدول</Button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead><tr><th className="th">الولاية</th><th className="th">منزل</th><th className="th">مكتب</th></tr></thead>
                  <tbody>
                    {rates.filter((r) => !rateQuery || r.wilayaAr.includes(rateQuery) || String(r.wilayaCode) === rateQuery).map((r, i) => (
                      <tr key={r.wilayaCode}>
                        <td className="td font-bold">{r.wilayaCode} — {r.wilayaAr}</td>
                        <td className="td"><Input type="number" value={r.home} onChange={(e) => setRates(rates.map((x) => x.wilayaCode === r.wilayaCode ? { ...x, home: +e.target.value } : x))} /></td>
                        <td className="td"><Input type="number" value={r.stopDesk} onChange={(e) => setRates(rates.map((x) => x.wilayaCode === r.wilayaCode ? { ...x, stopDesk: +e.target.value } : x))} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Free rules */}
            <Card>
              <div className="flex items-center justify-between mb-3">
                <h2 className="h2">قواعد الشحن المجاني</h2>
                <button className="btn-ghost !text-xs" onClick={() => { setRule({ label: "", type: "min_order", active: true }); setRuleOpen(true); }}><Plus className="w-3.5 h-3.5" /> إضافة</button>
              </div>
              {rules.length === 0 ? <p className="muted text-sm">لا توجد قواعد.</p> : (
                <div className="space-y-2">
                  {rules.map((r, i) => (
                    <div key={r.id} className="flex items-center justify-between border border-brown/10 rounded-lg px-3 py-2 text-sm">
                      <div>
                        <span className="font-bold">{r.label}</span>
                        <span className="text-xs text-brown/50 mr-2">({r.type})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="text-xs font-bold flex items-center gap-1"><input type="checkbox" checked={r.active} onChange={(e) => setRules(rules.map((x, xi) => xi === i ? { ...x, active: e.target.checked } : x))} /> فعّال</label>
                        <button className="text-red-500" onClick={() => setRules(rules.filter((_, xi) => xi !== i))}><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Modal open={ruleOpen} onClose={() => setRuleOpen(false)} title="قاعدة شحن مجاني" wide>
              <div className="space-y-3">
                <Field label="العنوان"><Input value={rule.label ?? ""} onChange={(e) => setRule({ ...rule, label: e.target.value })} placeholder="مثال: شحن مجاني للطلبات فوق 10000 دج" /></Field>
                <Field label="النوع"><Select value={rule.type} onChange={(e) => setRule({ ...rule, type: e.target.value as any })}>
                  <option value="all">الكل</option>
                  <option value="min_order">حد أدنى للطلب</option>
                  <option value="products">منتجات محددة</option>
                  <option value="wilayas">ولايات محددة</option>
                  <option value="period">فترة زمنية</option>
                </Select></Field>
                {rule.type === "min_order" && <Field label="حد أدنى (دج)"><Input type="number" value={rule.minOrder ?? 0} onChange={(e) => setRule({ ...rule, minOrder: +e.target.value })} /></Field>}
                {rule.type === "wilayas" && (
                  <div>
                    <label className="label">الولايات</label>
                    <div className="flex flex-wrap gap-1.5 max-h-32 overflow-auto border border-ink/10 rounded-lg p-2">
                      {WILAYAS.map((w) => (
                        <label key={w.code} className="flex items-center gap-1 text-xs font-bold">
                          <input type="checkbox" checked={(rule.wilayaCodes ?? []).includes(w.code)}
                            onChange={(e) => setRule({ ...rule, wilayaCodes: e.target.checked ? [...(rule.wilayaCodes ?? []), w.code] : (rule.wilayaCodes ?? []).filter((c) => c !== w.code) })} />
                          {w.code}
                        </label>
                      ))}
                    </div>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <Field label="من"><Input type="date" value={(rule.start ?? "").slice(0, 10)} onChange={(e) => setRule({ ...rule, start: e.target.value })} /></Field>
                  <Field label="إلى"><Input type="date" value={(rule.end ?? "").slice(0, 10)} onChange={(e) => setRule({ ...rule, end: e.target.value })} /></Field>
                </div>
                <div className="flex justify-end"><Button disabled={!rule.label} onClick={() => { setRules([...rules, { id: `rule-${Date.now()}`, label: rule.label!, type: rule.type as any, active: true, minOrder: rule.minOrder, wilayaCodes: rule.wilayaCodes, start: rule.start, end: rule.end }]); setRuleOpen(false); }}>حفظ</Button></div>
              </div>
            </Modal>
          </div>
        )}

        {/* Shipments */}
        {tab === "shipments" && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <Select value={shipFilter} onChange={(e) => setShipFilter(e.target.value as any)} className="!w-auto">
                <option value="all">الكل</option>
                <option value="live">API حي</option>
                <option value="local">محلي</option>
              </Select>
              <Select value={shipStatus} onChange={(e) => setShipStatus(e.target.value)} className="!w-auto">
                <option value="">كل الحالات</option>
                <option value="created">تم التسجيل</option>
                <option value="picked_up">تم الاستلام</option>
                <option value="in_transit">قيد النقل</option>
                <option value="out_for_delivery">خرج للتوصيل</option>
                <option value="delivered">تم التوصيل</option>
                <option value="returned">مرتجع</option>
              </Select>
              <button className="btn-gold !py-2 !text-sm" onClick={syncAll} disabled={syncingAll}><RefreshCcw className="w-4 h-4" /> مزامنة الكل</button>
            </div>
            {filteredShipments.length === 0 ? <p className="muted text-sm">لا توجد شحنات.</p> : (
              <Card className="!p-0 overflow-x-auto">
                <table className="w-full min-w-[900px]">
                  <thead><tr>
                    <th className="th">التتبع</th><th className="th">الطلب</th><th className="th">الحالة</th><th className="th">النوع</th>
                    <th className="th">المطلوب</th><th className="th">التكلفة الفعلية</th><th className="th">الوضع</th><th className="th">إجراءات</th>
                  </tr></thead>
                  <tbody>
                    {filteredShipments.map((sh) => (
                      <tr key={sh.id} className="hover:bg-warmbeige/50">
                        <td className="td font-bold" dir="ltr">{sh.trackingNumber}</td>
                        <td className="td"><a href={`/admin/orders`} className="text-golddark font-bold">{sh.orderId.slice(0, 8)}</a></td>
                        <td className="td"><Badge className={courierStatusColor(sh.status)}>{courierStatusLabel(sh.status)}</Badge></td>
                        <td className="td text-xs">{sh.method === "home" ? "منزل" : "مكتب"}</td>
                        <td className="td font-black">{money(sh.feeCharged)}</td>
                        <td className="td">
                          <input type="number" className="input !w-24 !py-1" value={sh.costActual ?? ""} onChange={(e) => setShipmentCost(sh.id, +e.target.value)} />
                        </td>
                        <td className="td"><Badge className={cn(sh.apiMode === "live" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")}>{sh.apiMode === "live" ? "API" : "محلي"}</Badge></td>
                        <td className="td">
                          <div className="flex items-center gap-2">
                            <button className="text-[10px] font-black text-golddark flex items-center gap-1" onClick={async () => { await syncShipment(sh.id); await load(); }}>
                              <RefreshCcw className="w-3 h-3" /> تحديث
                            </button>
                            {sh.apiMode === "live" && (
                              <a href={`/admin/shipments/${sh.id}/label`} target="_blank" rel="noreferrer" className="text-[10px] font-black text-golddark flex items-center gap-1">
                                طباعة
                              </a>
                            )}
                            <button className="text-[10px] font-black text-golddark flex items-center gap-1" onClick={() => setSelectedShipment(sh)}>
                              <MapPin className="w-3 h-3" /> تفاصيل
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            )}
          </div>
        )}
      </div>

      {/* Shipment detail modal */}
      <Modal open={!!selectedShipment} onClose={() => setSelectedShipment(null)} title="تفاصيل الشحنة" wide>
        {selectedShipment && (
          <div className="space-y-4">
            <TrackingMap shipment={selectedShipment} />
            <div className="flex justify-end">
              <Button onClick={() => setSelectedShipment(null)}>إغلاق</Button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}