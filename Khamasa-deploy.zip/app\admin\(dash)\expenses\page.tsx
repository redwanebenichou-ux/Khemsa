"use client";
import { useEffect, useState } from "react";
import { listExpenses, addExpense, deleteExpense, getSettings } from "@/lib/actions";
import type { Expense } from "@/lib/types";
import { Card, Badge, Empty, Button, Input, Field, Select, Modal } from "@/components/ui";
import { money } from "@/lib/utils";
import { Plus, Trash2 } from "lucide-react";

const CATS: Record<string, string> = { ads: "إعلانات", packaging: "تغليف", shipping: "توصيل", services: "خدمات", other: "أخرى" };

export default function ExpensesPage() {
  const [items, setItems] = useState<Expense[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ label: string; category: Expense["category"]; amount: number; date: string; note: string }>({ label: "", category: "ads", amount: 0, date: new Date().toISOString().slice(0, 10), note: "" });
  const [packaging, setPackaging] = useState(150);

  async function load() {
    const [ex, st] = await Promise.all([listExpenses(), getSettings()]);
    setItems(ex); setPackaging(st.packagingCost);
  }
  useEffect(() => { load(); }, []);

  const total = items.reduce((s, e) => s + e.amount, 0);
  const byCat = items.reduce((m: Record<string, number>, e) => { m[e.category] = (m[e.category] ?? 0) + e.amount; return m; }, {});

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="h1">المصاريف</h1><p className="muted mt-1">إعلانات، تغليف، توصيل فعلي وخدمات — تُخصم من صافي الربح تلقائياً</p></div>
        <Button onClick={() => setOpen(true)}><Plus className="w-4 h-4" /> مصروف جديد</Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <Card className="!p-4"><div className="text-xs font-bold text-ink/50">الإجمالي</div><div className="text-2xl font-black">{money(total)}</div></Card>
        {Object.entries(CATS).map(([k, label]) => (
          <Card key={k} className="!p-4"><div className="text-xs font-bold text-ink/50">{label}</div><div className="text-lg font-black">{money(byCat[k] ?? 0)}</div></Card>
        ))}
      </div>

      <Card className="!bg-beige/40">
        <div className="text-sm font-bold">💡 تكلفة التغليف الافتراضية لكل طلب: {money(packaging)} — عدّلها من صفحة الإعدادات. تكلفة التوصيل الفعلية تُدخل من صفحة تفاصيل الطلب (Shipment).</div>
      </Card>

      {items.length === 0 ? <Empty text="لا توجد مصاريف بعد" /> : (
        <Card className="!p-0 overflow-x-auto">
          <table className="w-full">
            <thead><tr><th className="th px-4 pt-4">التاريخ</th><th className="th">البند</th><th className="th">الفئة</th><th className="th">المبلغ</th><th className="th">ملاحظة</th><th className="th px-4 pt-4">—</th></tr></thead>
            <tbody>
              {items.map((e) => (
                <tr key={e.id} className="hover:bg-beige/40">
                  <td className="td px-4 text-xs">{e.date}</td><td className="td font-bold">{e.label}</td>
                  <td className="td"><Badge className="bg-beige text-brown">{CATS[e.category]}</Badge></td>
                  <td className="td font-black text-red-600">{money(e.amount)}</td>
                  <td className="td text-xs muted">{e.note ?? "—"}</td>
                  <td className="td px-4"><button className="text-red-500" onClick={async () => { await deleteExpense(e.id); load(); }}><Trash2 className="w-4 h-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="إضافة مصروف">
        <div className="space-y-3">
          <Field label="البند"><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="مثال: حملة إعلان فيسبوك — ديسمبر" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الفئة">
              <Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as Expense["category"] })}>
                {Object.entries(CATS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </Select>
            </Field>
            <Field label="المبلغ"><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: +e.target.value })} /></Field>
          </div>
          <Field label="التاريخ"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          <Field label="ملاحظة"><Input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></Field>
          <div className="flex justify-end">
            <Button disabled={!form.label || form.amount <= 0} onClick={async () => { await addExpense(form); setOpen(false); load(); }}>حفظ</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
